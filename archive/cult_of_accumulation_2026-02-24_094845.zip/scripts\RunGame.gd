extends Control

@onready var week_label: Label = $RootVBox/TopBar/TopBarHBox/WeekBox/WeekLabel
@onready var target_label: Label = $RootVBox/TopBar/TopBarHBox/TargetBox/TargetLabel
@onready var blood_label: Label = $RootVBox/TopBar/TopBarHBox/BloodBox/BloodLabel

@onready var selected_list: Label = $RootVBox/MiddleArea/SelectedPanel/SelectedVBox/SelectedList
@onready var preview_label: Label = $RootVBox/MiddleArea/SelectedPanel/SelectedVBox/PreviewLabel
@onready var breakdown_text: Label = $RootVBox/MiddleArea/BreakdownPanel/BreakdownVBox/BreakdownScroll/BreakdownText
@onready var doctrine_label: Label = $RootVBox/MiddleArea/DoctrinePanel/DoctrineHBox/DoctrineLabel
@onready var doctrine_hint: Label = $RootVBox/MiddleArea/DoctrinePanel/DoctrineHBox/DoctrineHint
@onready var doctrine_button: Button = $RootVBox/MiddleArea/DoctrinePanel/DoctrineHBox/DoctrineAction
@onready var pool_button: Button = $RootVBox/MiddleArea/DoctrinePanel/DoctrineHBox/PoolButton
@onready var pool_overlay: Control = $PoolOverlay
@onready var pool_summary: Label = $PoolOverlay/PoolCenter/PoolPanel/PoolVBox/PoolSummary
@onready var pool_list: VBoxContainer = $PoolOverlay/PoolCenter/PoolPanel/PoolVBox/PoolScroll/PoolList
@onready var pool_close: Button = $PoolOverlay/PoolCenter/PoolPanel/PoolVBox/PoolClose

@onready var confirm_button: Button = $RootVBox/BottomBar/BottomHBox/ConfirmButton
@onready var clear_button: Button = $RootVBox/BottomBar/BottomHBox/ClearButton
@onready var gs: Node = get_node("/root/GameState")

var card_buttons: Array[Button] = []
var confirmed: bool = false
var confirmed_pass: bool = false
var last_selected_indices: Array[int] = []

func _ready() -> void:
	card_buttons = [
		$RootVBox/MiddleArea/HandPanel/HandVBox/HandBox/Card1,
		$RootVBox/MiddleArea/HandPanel/HandVBox/HandBox/Card2,
		$RootVBox/MiddleArea/HandPanel/HandVBox/HandBox/Card3,
		$RootVBox/MiddleArea/HandPanel/HandVBox/HandBox/Card4,
		$RootVBox/MiddleArea/HandPanel/HandVBox/HandBox/Card5,
		$RootVBox/MiddleArea/HandPanel/HandVBox/HandBox/Card6,
	]

	for i in range(card_buttons.size()):
		var btn: Button = card_buttons[i]
		btn.toggled.connect(_on_card_toggled.bind(i))

	confirm_button.pressed.connect(_on_confirm_pressed)
	clear_button.pressed.connect(_on_clear_pressed)
	doctrine_button.pressed.connect(_on_doctrine_pressed)
	pool_button.pressed.connect(_on_pool_pressed)
	pool_close.pressed.connect(_on_pool_close_pressed)

	if gs.current_hand.size() != 6:
		gs.draw_hand_from_pool()

	_refresh_ui()

func _refresh_ui() -> void:
	week_label.text = "Week %d/5 (Round %d/2)" % [gs.current_week, gs.week_round]
	target_label.text = "Target: %d" % gs.get_week_target(gs.current_week)
	blood_label.text = "Blood: %d" % gs.blood_currency
	breakdown_text.text = gs.last_breakdown_text
	_update_doctrine_ui()

	for i in range(card_buttons.size()):
		_update_card_visual(i)

	_update_selected_list()
	_update_confirm_state()

func _update_doctrine_ui() -> void:
	var name: String = gs.selected_doctrine
	if name == "":
		doctrine_label.text = "Doctrine: -"
		doctrine_hint.text = "Choose a doctrine"
		doctrine_button.disabled = true
		return
	if name == "FLESH":
		doctrine_label.text = "Doctrine: Path of Flesh"
		doctrine_hint.text = "Convert one follower to BLOOD"
	elif name == "RUIN":
		doctrine_label.text = "Doctrine: Path of Ruin"
		doctrine_hint.text = "Refine +1 tier, exhaust this play"
	else:
		doctrine_label.text = "Doctrine: Path of Silence"
		doctrine_hint.text = "Banish one follower, replace it"
	doctrine_button.disabled = gs.doctrine_used_this_play or confirmed
	pool_button.disabled = false

func _get_trait_color(trait_name: String) -> Color:
	match trait_name:
		"BLOOD":
			return Color(0.75, 0.2, 0.2)
		"BONE":
			return Color(0.85, 0.85, 0.85)
		"VOID":
			return Color(0.25, 0.2, 0.35)
		_:
			return Color(0.5, 0.5, 0.5)

func _get_trait_font_color(trait_name: String) -> Color:
	if trait_name == "VOID":
		return Color(0.95, 0.95, 0.95)
	return Color(0.1, 0.1, 0.1)

func _make_style(bg: Color, selected: bool) -> StyleBoxFlat:
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = Color(1.0, 0.9, 0.2) if selected else Color(0.1, 0.1, 0.1)
	var bw: int = 4 if selected else 1
	sb.border_width_left = bw
	sb.border_width_right = bw
	sb.border_width_top = bw
	sb.border_width_bottom = bw
	sb.corner_radius_top_left = 6
	sb.corner_radius_top_right = 6
	sb.corner_radius_bottom_left = 6
	sb.corner_radius_bottom_right = 6
	sb.content_margin_left = 8
	sb.content_margin_right = 8
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	return sb

func _update_card_visual(i: int) -> void:
	var btn: Button = card_buttons[i]
	var follower: Dictionary = gs.current_hand[i]
	var tier: int = follower["tier"]
	var trait_name: String = follower["trait"]
	var exhausted: bool = follower["exhausted"]

	if exhausted:
		btn.text = "T%d\n%s\nEXHAUSTED" % [tier, trait_name]
	else:
		btn.text = "T%d\n%s" % [tier, trait_name]
	var bg: Color = _get_trait_color(trait_name)
	var selected: bool = btn.button_pressed
	var style: StyleBoxFlat = _make_style(bg, selected)

	btn.add_theme_stylebox_override("normal", style)
	btn.add_theme_stylebox_override("hover", style)
	btn.add_theme_stylebox_override("pressed", style)
	btn.add_theme_stylebox_override("disabled", style)
	btn.add_theme_stylebox_override("focus", style)
	btn.add_theme_color_override("font_color", _get_trait_font_color(trait_name))
	btn.add_theme_color_override("font_pressed_color", _get_trait_font_color(trait_name))

func _update_selected_list() -> void:
	var parts: Array[String] = []
	var selected_indices: Array[int] = []
	for i in range(card_buttons.size()):
		if card_buttons[i].button_pressed:
			var follower: Dictionary = gs.current_hand[i]
			parts.append("#%d %s(%d)" % [i + 1, follower["trait"], follower["tier"]])
			selected_indices.append(i)

	if parts.is_empty():
		selected_list.text = "(none)"
		preview_label.text = "Preview: 0 devotion"
	else:
		selected_list.text = ", ".join(parts)
		var preview: Dictionary = gs.preview_selected(selected_indices)
		var add_val: int = int(preview["additive_total"])
		var base_val: int = int(preview["base"])
		var exp_val: int = int(preview["exponent"])
		var mult_val: int = int(preview["multiplier"])
		var final_val: int = int(preview["final_devotion"])
		var blood_terms: Array = preview["blood_terms"]
		var bone_terms: Array = preview["bone_terms"]
		var void_count: int = int(preview["void_count"])
		var calcify_total: int = int(preview["calcify_total"])
		var quick_total: int = int(preview["quick_total"])
		var thin_total: int = int(preview["thin_total"])
		var ossuary_total: int = int(preview["ossuary_total"])
		var polisher_total: int = int(preview["polisher_total"])
		var symmetry_total: int = int(preview["symmetry_total"])
		var refined_void_count: int = int(preview["refined_void_count"])
		var order_mult: int = int(preview["order_mult"])
		var balanced_mult: int = int(preview["balanced_mult"])
		var doctrine_add: int = int(preview["doctrine_additive"])
		var doctrine_line: String = "none"
		if preview.has("doctrine_lines") and preview["doctrine_lines"].size() > 0:
			doctrine_line = preview["doctrine_lines"][0]

		var preview_lines: Array[String] = []
		preview_lines.append("Preview")
		preview_lines.append("Followers:")
		preview_lines.append("BLOOD = " + (" + ".join(blood_terms) if blood_terms.size() > 0 else "0"))
		preview_lines.append("BONE = " + (" + ".join(bone_terms) if bone_terms.size() > 0 else "0"))
		preview_lines.append("VOID count = %d" % void_count)
		var relic_math: Array[String] = []
		if calcify_total > 0:
			relic_math.append("Calcify +%d" % calcify_total)
		if quick_total > 0:
			relic_math.append("Quick +%d" % quick_total)
		if thin_total > 0:
			relic_math.append("Thin +%d" % thin_total)
		if ossuary_total > 0:
			relic_math.append("Ossuary +%d" % ossuary_total)
		if polisher_total > 0:
			relic_math.append("Polisher +%d" % polisher_total)
		if symmetry_total > 0:
			relic_math.append("Symmetry +%d" % symmetry_total)
		if doctrine_add != 0:
			relic_math.append("Doctrine %+d" % doctrine_add)
		if refined_void_count > 0:
			relic_math.append("Refined VOID +0.5 mult each (x%d)" % refined_void_count)
		var relic_line: String = "Relic math = " + (", ".join(relic_math) if relic_math.size() > 0 else "none")
		preview_lines.append(relic_line)
		if order_mult > 1:
			preview_lines.append("Order x%d" % order_mult)
		if balanced_mult > 1:
			preview_lines.append("Balanced x%d" % balanced_mult)
		preview_lines.append("Starting path = %s" % doctrine_line)
		preview_lines.append("Total = %d (Add %d x %d)" % [final_val, add_val, mult_val])
		preview_label.text = "\n".join(preview_lines)

func _update_confirm_state() -> void:
	if confirmed:
		confirm_button.show()
		confirm_button.text = "Continue"
		confirm_button.disabled = false
		clear_button.disabled = true
		doctrine_button.disabled = true
		pool_button.disabled = true
		for btn in card_buttons:
			btn.disabled = true
		return

	for btn in card_buttons:
		btn.disabled = false
	var selected_count: int = 0
	for btn in card_buttons:
		if btn.button_pressed:
			selected_count += 1
	confirm_button.show()
	confirm_button.text = "Confirm Sacrifice"
	confirm_button.disabled = selected_count != 3
	clear_button.disabled = selected_count == 0
	doctrine_button.disabled = gs.doctrine_used_this_play
	pool_button.disabled = false

func _on_card_toggled(toggled_on: bool, index: int) -> void:
	if toggled_on and gs.current_hand[index]["exhausted"]:
		card_buttons[index].button_pressed = false
		_update_card_visual(index)
		_show_info("(Info) Exhausted: cannot sacrifice this play.")
		return
	if toggled_on:
		var selected_count: int = 0
		for btn in card_buttons:
			if btn.button_pressed:
				selected_count += 1
		if selected_count > 3:
			card_buttons[index].button_pressed = false
			_update_card_visual(index)
			_show_info("(Info) Max 3 sacrifices per play.")
			return
	_update_card_visual(index)
	_update_selected_list()
	_update_confirm_state()

func _on_clear_pressed() -> void:
	for i in range(card_buttons.size()):
		card_buttons[i].button_pressed = false
		_update_card_visual(i)
	_update_selected_list()
	_update_confirm_state()

func _on_confirm_pressed() -> void:
	if confirmed:
		_proceed_after_confirm()
		return

	var selected_indices: Array[int] = []
	for i in range(card_buttons.size()):
		if card_buttons[i].button_pressed:
			selected_indices.append(i)

	if selected_indices.size() != 3:
		_show_info("(Info) Select exactly 3 followers.")
		return

	var blood_before: int = gs.blood_currency
	var result: Dictionary = gs.score_selected(selected_indices)
	last_selected_indices = selected_indices
	confirmed = true
	confirmed_pass = result["pass"]
	gs.week_total_devotion += int(result["final_devotion"])
	var round_header: String = "Round %d Result" % gs.week_round
	var combined_line: String = "Week total devotion: %d / Target %d" % [gs.week_total_devotion, result["target"]]
	var combined_status: String = "Status: %s" % ("ON TRACK" if gs.week_total_devotion >= result["target"] else "NEED MORE")
	var combined_block: String = round_header + "\n" + result["breakdown"] + "\n\n" + combined_line + "\n" + combined_status
	if gs.last_breakdown_text == "":
		gs.last_breakdown_text = combined_block
	else:
		gs.last_breakdown_text += "\n\n" + combined_block
	breakdown_text.text = gs.last_breakdown_text
	blood_label.text = "Blood: %d" % gs.blood_currency
	var blood_after: int = gs.blood_currency
	var sacrifices: String = _sacrifice_summary(selected_indices)
	gs.log_message("ROUND | Week %d Round %d | Target %d | Devotion %d | Add %d | Mult %d (base %d exp %d) | Blood %d->%d | Sac: %s | Doctrine: %s | Relics: %s" % [
		gs.current_week,
		gs.week_round,
		result["target"],
		int(result["final_devotion"]),
		int(result["additive_total"]),
		int(result["multiplier"]),
		int(result["base"]),
		int(result["exponent"]),
		blood_before,
		blood_after,
		sacrifices,
		(gs.selected_doctrine if gs.selected_doctrine != "" else "none"),
		gs._relic_summary(),
	])
	_update_confirm_state()
	_update_doctrine_ui()

func _proceed_after_confirm() -> void:
	gs.resolve_play_and_update_pool(last_selected_indices)
	var target: int = gs.get_week_target(gs.current_week)
	if gs.week_total_devotion >= target:
		var bonus_cup: int = gs.relic_inventory["Ceremonial Cup"]
		var bonus_geo: int = gs.relic_inventory["Blasphemous Geometry"]
		var bonus_total: int = bonus_cup + (bonus_geo * 3)
		if bonus_total > 0:
			var before: int = gs.blood_currency
			gs.blood_currency += bonus_total
			var bonus_line: String = "Success bonuses: Ceremonial Cup +%d, Blasphemous Geometry +%d (Blood %d -> %d)" % [
				bonus_cup,
				bonus_geo * 3,
				before,
				gs.blood_currency,
			]
			gs.last_breakdown_text += "\n" + bonus_line
			breakdown_text.text = gs.last_breakdown_text
			gs.log_message("SUCCESS BONUS | Week %d | +%d Blood (Cup %d, Geometry %d)" % [
				gs.current_week,
				bonus_total,
				bonus_cup,
				bonus_geo * 3,
			])
		if gs.current_week >= 5:
			get_tree().change_scene_to_file("res://scenes/Victory.tscn")
		else:
			get_tree().change_scene_to_file("res://scenes/Shop.tscn")
		return

	if gs.week_round == 1:
		gs.week_round = 2
		confirmed = false
		confirmed_pass = false
		last_selected_indices = []
		gs.reset_doctrine_for_play()
		gs.draw_hand_from_pool()
		_on_clear_pressed()
		_refresh_ui()
		return

	if gs.week_round == 2:
		get_tree().change_scene_to_file("res://scenes/GameOver.tscn")

func _on_doctrine_pressed() -> void:
	if gs.doctrine_used_this_play or confirmed:
		return
	var selected_indices: Array[int] = []
	for i in range(card_buttons.size()):
		if card_buttons[i].button_pressed:
			selected_indices.append(i)
	if selected_indices.size() != 1:
		_show_info("(Info) Select exactly 1 card for Doctrine Action.")
		return
	var idx: int = int(selected_indices[0])
	var follower: Dictionary = gs.current_hand[idx]
	if gs.selected_doctrine == "FLESH":
		if follower["trait"] == "BLOOD":
			_show_info("(Info) Doctrine (Flesh): Already BLOOD.")
		else:
			follower["trait"] = "BLOOD"
			gs.current_hand[idx] = follower
			_show_info("Doctrine (Flesh): Converted #%d to BLOOD." % [idx + 1])
			gs.doctrine_used_this_play = true
	elif gs.selected_doctrine == "RUIN":
		var new_tier: int = min(6, int(follower["tier"]) + 1)
		follower["tier"] = new_tier
		follower["exhausted"] = true
		gs.current_hand[idx] = follower
		card_buttons[idx].button_pressed = false
		_show_info("Doctrine (Ruin): Refined #%d to T%d (exhausted)." % [idx + 1, new_tier])
		gs.doctrine_used_this_play = true
	elif gs.selected_doctrine == "SILENCE":
		gs.current_hand[idx] = gs.make_random_follower("random")
		card_buttons[idx].button_pressed = false
		_show_info("Doctrine (Silence): Banished #%d and replaced it." % [idx + 1])
		gs.doctrine_used_this_play = true
	_update_card_visual(idx)
	_update_selected_list()
	_update_confirm_state()

func _show_info(msg: String) -> void:
	if gs.last_breakdown_text == "":
		breakdown_text.text = msg
	else:
		breakdown_text.text = msg + "\n\n" + gs.last_breakdown_text

func _on_pool_pressed() -> void:
	_refresh_pool_overlay()
	pool_overlay.visible = true

func _on_pool_close_pressed() -> void:
	pool_overlay.visible = false

func _refresh_pool_overlay() -> void:
	for child in pool_list.get_children():
		child.queue_free()
	var summary: Dictionary = gs.pool_summary_counts()
	pool_summary.text = "Pool Size: %d | Blood: %d  Bone: %d  Void: %d | Avg Tier: %.1f" % [
		summary["total"],
		summary["blood"],
		summary["bone"],
		summary["void"],
		float(summary["avg_tier"]),
	]
	for f in gs.pool:
		var row: PanelContainer = PanelContainer.new()
		var hbox: HBoxContainer = HBoxContainer.new()
		row.add_child(hbox)
		var stripe: ColorRect = ColorRect.new()
		stripe.custom_minimum_size = Vector2(12, 0)
		stripe.color = _get_trait_color(f["trait"])
		hbox.add_child(stripe)
		var label: Label = Label.new()
		label.text = "%s  T%d  (%s #%d)" % [f["trait"], int(f["tier"]), f["origin_tag"], int(f["id"])]
		hbox.add_child(label)
		pool_list.add_child(row)

func _sacrifice_summary(selected_indices: Array[int]) -> String:
	var parts: Array[String] = []
	for i in selected_indices:
		if i >= 0 and i < gs.current_hand.size():
			var f: Dictionary = gs.current_hand[i]
			parts.append("#%d %s(%d)" % [i + 1, f["trait"], f["tier"]])
	if parts.is_empty():
		return "(none)"
	return ", ".join(parts)
