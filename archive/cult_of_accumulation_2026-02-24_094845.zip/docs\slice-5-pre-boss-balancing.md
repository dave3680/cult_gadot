# Slice 5: Pre-Boss Balancing And Power Caps

## Objective
Stabilize growth and prevent runaway multiplier stacking before introducing bosses or higher-stakes challenges.

## Systems Introduced Or Modified
- Add caps or soft caps on multiplier exponent growth.
- Add belief and trait stacking limits at the scoring pipeline level.
- Week-based scaling adjustments for relic cost and effect ceilings.

## Why This Slice Is Sequenced Here
After adding combinatorial depth, balance is required to keep the core loop skillful and stable through Week 5.

## Detailed System Description
- **Multiplier cap**: implement a soft cap formula that reduces benefit after a threshold.
- **Belief stacking rules**: only one belief effect can trigger per scoring step, or cap total belief contributions.
- **Trait stack limits**: cap repeated triggers from common traits per play.
- **Economy tuning**: adjust relic costs to align with new power sources.

## Required Data Model Changes
- Add per-run or per-week `cap_parameters` values.
- Add scoring pipeline metadata to track applied effect counts.

## UI Implications
- Add minimal UI feedback when a cap is hit (small icon or log entry).
- No changes to layout.

## Risk Analysis (Balance Dangers)
- Risk: caps feel punitive or opaque.
- Mitigation: soft caps with visible feedback and clear thresholds in tooltip text.

## Interaction With Existing Systems
- Scoring pipeline enforces caps across additive, multiplier, relic, and doctrine modifiers.
- Doctrines like Blood Straight must be audited to respect caps.

## Done Criteria
- Multipliers cannot exceed defined soft cap behavior.
- Belief and trait stacking is capped in pipeline.
- Week 1�3 skill expression remains intact and measurable.
- Relic economy remains viable after cap changes.
