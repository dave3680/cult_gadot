extends Node

const TRAITS := ["BLOOD", "BONE", "VOID"]
const RELICS := [
	"Ritual Knife",
	"Bone Idol",
	"Crimson Book",
	"Hollow Chant",
	"Sacrificial Order",
	"Ceremonial Cup",
	"Blood Abacus",
	"Quick Chant",
	"Thin Blade",
	"Tithe Discount",
	"Ossuary Standard",
	"Bone Polisher",
	"Ritual Symmetry",
	"Calcify",
	"Crimson Interest",
	"Void Prism",
	"Black Candle",
	"The Third Knife",
	"Balanced Offering",
	"Blasphemous Geometry",
]

const RELIC_DEFS := {
	"Ritual Knife": {"rarity": "COMMON", "stacks": false, "desc": "The first follower you choose each week counts as double tier."},
	"Bone Idol": {"rarity": "COMMON", "stacks": true, "desc": "BONE followers are worth more."},
	"Crimson Book": {"rarity": "COMMON", "stacks": true, "desc": "Each BLOOD sacrifice adds a small bonus."},
	"Hollow Chant": {"rarity": "UNCOMMON", "stacks": true, "desc": "VOID sacrifices boost your multiplier harder."},
	"Sacrificial Order": {"rarity": "UNCOMMON", "stacks": true, "desc": "Exactly 3 sacrifices? Big devotion bonus."},
	"Ceremonial Cup": {"rarity": "COMMON", "stacks": true, "desc": "On a win, gain extra Blood before the shop."},
	"Blood Abacus": {"rarity": "COMMON", "stacks": true, "desc": "BLOOD sacrifices give extra Blood currency (does not change devotion)."},
	"Quick Chant": {"rarity": "COMMON", "stacks": true, "desc": "Any sacrifice grants a small devotion boost."},
	"Thin Blade": {"rarity": "COMMON", "stacks": true, "desc": "Sacrifice just 1? Gain a big devotion boost."},
	"Tithe Discount": {"rarity": "COMMON", "stacks": false, "desc": "Relics cost 1 less Blood (min 2)."},
	"Ossuary Standard": {"rarity": "UNCOMMON", "stacks": true, "desc": "Sacrifice at least 2 BONE to gain bonus devotion."},
	"Bone Polisher": {"rarity": "UNCOMMON", "stacks": true, "desc": "Your strongest BONE adds extra devotion."},
	"Ritual Symmetry": {"rarity": "UNCOMMON", "stacks": true, "desc": "Even-numbered sacrifices gain bonus devotion."},
	"Calcify": {"rarity": "UNCOMMON", "stacks": true, "desc": "Each BONE sacrifice adds extra devotion."},
	"Crimson Interest": {"rarity": "UNCOMMON", "stacks": true, "desc": "After the shop, earn bonus Blood based on your stash."},
	"Void Prism": {"rarity": "RARE", "stacks": true, "desc": "VOID sacrifices count as extra for your multiplier."},
	"Black Candle": {"rarity": "RARE", "stacks": false, "desc": "Your multiplier never starts below 2."},
	"The Third Knife": {"rarity": "RARE", "stacks": false, "desc": "The first three followers you choose each week count as double tier."},
	"Balanced Offering": {"rarity": "RARE", "stacks": true, "desc": "If you offer BLOOD, BONE, and VOID, devotion is doubled."},
	"Blasphemous Geometry": {"rarity": "RARE", "stacks": true, "desc": "On a win, gain a large Blood bonus before the shop."},
}

var current_week: int = 1
var blood_currency: int = 0
var week_round: int = 1
var week_total_devotion: int = 0
var selected_doctrine: String = ""
var doctrine_used_this_play: bool = false
var pool: Array[Dictionary] = []
var next_follower_id: int = 1
var shop_recruit_offers: Array[Dictionary] = []
var shop_recruit_purchased: Array[bool] = []
var relic_inventory: Dictionary = {
	"Ritual Knife": 0,
	"Bone Idol": 0,
	"Crimson Book": 0,
	"Hollow Chant": 0,
	"Sacrificial Order": 0,
	"Ceremonial Cup": 0,
	"Blood Abacus": 0,
	"Quick Chant": 0,
	"Thin Blade": 0,
	"Tithe Discount": 0,
	"Ossuary Standard": 0,
	"Bone Polisher": 0,
	"Ritual Symmetry": 0,
	"Calcify": 0,
	"Crimson Interest": 0,
	"Void Prism": 0,
	"Black Candle": 0,
	"The Third Knife": 0,
	"Balanced Offering": 0,
	"Blasphemous Geometry": 0,
}
var current_hand: Array[Dictionary] = []
var last_breakdown_text: String = ""
var last_logs: Array[String] = []

var _rng: RandomNumberGenerator = RandomNumberGenerator.new()

func _ready() -> void:
	_rng.randomize()

func reset_run() -> void:
	current_week = 1
	blood_currency = 0
	week_round = 1
	week_total_devotion = 0
	selected_doctrine = ""
	doctrine_used_this_play = false
	pool.clear()
	next_follower_id = 1
	shop_recruit_offers.clear()
	shop_recruit_purchased.clear()
	for k in relic_inventory.keys():
		relic_inventory[k] = 0
	last_breakdown_text = ""
	last_logs.clear()
	current_hand.clear()

func draw_new_hand() -> void:
	current_hand.clear()
	for i in range(6):
		current_hand.append(_make_follower())

func _make_follower() -> Dictionary:
	var tier: int = _rng.randi_range(1, 5)
	var roll: float = _rng.randf()
	var trait_name: String = "BLOOD"
	if roll < 0.6:
		trait_name = "BLOOD"
	elif roll < 0.9:
		trait_name = "BONE"
	else:
		trait_name = "VOID"
		tier = 0
	return {"id": _next_id(), "tier": tier, "trait": trait_name, "exhausted": false, "origin_tag": "random"}

func _next_id() -> int:
	var id: int = next_follower_id
	next_follower_id += 1
	return id

func replace_sacrificed(indices: Array[int]) -> void:
	for idx in indices:
		if idx >= 0 and idx < current_hand.size():
			current_hand[idx] = _make_follower()

func start_week() -> void:
	week_round = 1
	week_total_devotion = 0
	last_breakdown_text = ""
	doctrine_used_this_play = false
	current_hand.clear()

func init_starting_pool(doctrine: String) -> void:
	pool.clear()
	next_follower_id = 1
	var entries: Array[Dictionary] = []
	if doctrine == "FLESH":
		entries = [
			{"trait": "BLOOD", "tier": 1}, {"trait": "BLOOD", "tier": 1}, {"trait": "BLOOD", "tier": 1},
			{"trait": "BLOOD", "tier": 2}, {"trait": "BLOOD", "tier": 2}, {"trait": "BLOOD", "tier": 2},
			{"trait": "BLOOD", "tier": 3}, {"trait": "BLOOD", "tier": 3},
			{"trait": "BONE", "tier": 2}, {"trait": "BONE", "tier": 2}, {"trait": "BONE", "tier": 3},
			{"trait": "VOID", "tier": _rng.randi_range(1, 2)},
		]
	elif doctrine == "RUIN":
		entries = [
			{"trait": "BLOOD", "tier": 1}, {"trait": "BLOOD", "tier": 1},
			{"trait": "BLOOD", "tier": 2}, {"trait": "BLOOD", "tier": 2},
			{"trait": "BLOOD", "tier": 3}, {"trait": "BLOOD", "tier": 3},
			{"trait": "BONE", "tier": 1}, {"trait": "BONE", "tier": 1},
			{"trait": "BONE", "tier": 2}, {"trait": "BONE", "tier": 2},
			{"trait": "BONE", "tier": 3},
			{"trait": "VOID", "tier": _rng.randi_range(1, 2)},
		]
	else:
		entries = [
			{"trait": "BLOOD", "tier": 1}, {"trait": "BLOOD", "tier": 1}, {"trait": "BLOOD", "tier": 1},
			{"trait": "BLOOD", "tier": 2}, {"trait": "BLOOD", "tier": 2},
			{"trait": "BLOOD", "tier": 3}, {"trait": "BLOOD", "tier": 3},
			{"trait": "BONE", "tier": 1}, {"trait": "BONE", "tier": 2}, {"trait": "BONE", "tier": 3},
			{"trait": "VOID", "tier": _rng.randi_range(1, 2)},
			{"trait": "VOID", "tier": _rng.randi_range(1, 2)},
		]
	for e in entries:
		pool.append(_make_specific_follower(e["trait"], int(e["tier"]), "start"))

func _make_specific_follower(trait_name: String, tier: int, origin: String) -> Dictionary:
	var t: int = tier
	var tr: String = trait_name
	if tr == "VOID":
		t = 0
	return {"id": _next_id(), "tier": t, "trait": tr, "exhausted": false, "origin_tag": origin}

func make_random_follower(origin: String) -> Dictionary:
	var tier: int = _rng.randi_range(1, 5)
	var roll: float = _rng.randf()
	var trait_name: String = "BLOOD"
	if roll < 0.6:
		trait_name = "BLOOD"
	elif roll < 0.9:
		trait_name = "BONE"
	else:
		trait_name = "VOID"
	if trait_name == "VOID":
		tier = 0
	return {"id": _next_id(), "tier": tier, "trait": trait_name, "exhausted": false, "origin_tag": origin}

func generate_shop_recruits() -> void:
	shop_recruit_offers.clear()
	shop_recruit_purchased.clear()
	var tries: int = 0
	while shop_recruit_offers.size() < 3 and tries < 100:
		tries += 1
		var roll_trait: float = _rng.randf()
		var trait_name: String = "BLOOD"
		if roll_trait < 0.70:
			trait_name = "BLOOD"
		elif roll_trait < 0.95:
			trait_name = "BONE"
		else:
			trait_name = "VOID"

		var roll_tier: float = _rng.randf()
		var tier: int = 1
		if roll_tier < 0.80:
			tier = _rng.randi_range(1, 3)
		else:
			tier = 4
		if trait_name == "VOID":
			tier = 0

		var dup: bool = false
		for f in shop_recruit_offers:
			if f["trait"] == trait_name and int(f["tier"]) == tier:
				dup = true
				break
		if dup:
			continue
		shop_recruit_offers.append(_make_specific_follower(trait_name, tier, "recruit_shop"))
		shop_recruit_purchased.append(false)

func buy_shop_recruit(index: int) -> Dictionary:
	if index < 0 or index >= shop_recruit_offers.size():
		return {"ok": false, "reason": "invalid"}
	if shop_recruit_purchased[index]:
		return {"ok": false, "reason": "purchased"}
	if blood_currency < 1:
		return {"ok": false, "reason": "blood"}
	if pool.size() >= 40:
		return {"ok": false, "reason": "full"}
	blood_currency -= 1
	shop_recruit_purchased[index] = true
	var f: Dictionary = shop_recruit_offers[index]
	pool.append(f)
	log_message("Shop recruit purchased: %s tier %d (id %d), blood now %d, pool size %d" % [
		f["trait"], int(f["tier"]), int(f["id"]), blood_currency, pool.size()
	])
	return {"ok": true}

func ensure_pool_minimum_for_draw() -> void:
	if pool.size() >= 6:
		return
	var needed: int = 6 - pool.size()
	for i in range(needed):
		var roll: float = _rng.randf()
		var trait_name: String = "BLOOD"
		if roll < 0.85:
			trait_name = "BLOOD"
		else:
			trait_name = "BONE"
		var tier: int = _rng.randi_range(1, 3)
		pool.append(_make_specific_follower(trait_name, tier, "recruit"))

func draw_hand_from_pool() -> void:
	ensure_pool_minimum_for_draw()
	current_hand.clear()
	pool.shuffle()
	for i in range(6):
		current_hand.append(pool.pop_back())

func resolve_play_and_update_pool(selected_indices: Array[int]) -> void:
	var selected_set: Dictionary = {}
	for idx in selected_indices:
		selected_set[idx] = true
	var survivors: Array[Dictionary] = []
	for i in range(current_hand.size()):
		if not selected_set.has(i):
			survivors.append(current_hand[i])
	for s in survivors:
		s["exhausted"] = false
		pool.append(s)
	current_hand.clear()

func perform_weekly_breeding(week_cleared: int) -> void:
	var before: int = pool.size()
	var shuffled: Array = pool.duplicate()
	shuffled.shuffle()
	var newborns: Array[Dictionary] = []
	var couples: int = int(floor(shuffled.size() / 2.0))
	var idx: int = 0
	for i in range(couples):
		var a: Dictionary = shuffled[idx]
		var b: Dictionary = shuffled[idx + 1]
		idx += 2
		var chance: float = _breeding_chance(a["trait"], b["trait"])
		if _rng.randf() > chance:
			continue
		var baby_trait: String = _inherit_trait_breeding(a["trait"], b["trait"])
		var base_tier: int = int(floor((int(a["tier"]) + int(b["tier"])) / 2.0))
		var roll: float = _rng.randf()
		if roll < 0.2:
			base_tier += 1
		elif roll < 0.3:
			base_tier -= 1
		base_tier = clamp(base_tier, 1, 6)
		if baby_trait == "VOID":
			base_tier = 0
		newborns.append(_make_specific_follower(baby_trait, base_tier, "bred"))

	var trimmed: int = 0
	var cap: int = 40
	if pool.size() + newborns.size() > cap:
		trimmed = (pool.size() + newborns.size()) - cap
		newborns = newborns.slice(0, newborns.size() - trimmed)

	for nb in newborns:
		pool.append(nb)

	var summary: Dictionary = pool_summary_counts()
	log_message("BREEDING | Week %d | Pool %d->%d | Couples %d | Newborns %d | B:%d Bo:%d V:%d | Trimmed %d" % [
		week_cleared,
		before,
		pool.size(),
		couples,
		newborns.size(),
		summary["blood"],
		summary["bone"],
		summary["void"],
		trimmed,
	])

func _breeding_chance(a: String, b: String) -> float:
	if a == "VOID" and b == "VOID":
		return 0.25
	if a == "VOID" or b == "VOID":
		return 0.15
	return 0.35

func _inherit_trait_breeding(a: String, b: String) -> String:
	if a == b:
		return a
	var pick: String = a if _rng.randf() < 0.5 else b
	if (a == "VOID" or b == "VOID") and pick == "VOID":
		return "VOID" if _rng.randf() < 0.30 else (b if a == "VOID" else a)
	return pick

func pool_summary_counts() -> Dictionary:
	var blood: int = 0
	var bone: int = 0
	var voids: int = 0
	var total_tier: int = 0
	for f in pool:
		var tr: String = f["trait"]
		if tr == "BLOOD":
			blood += 1
		elif tr == "BONE":
			bone += 1
		else:
			voids += 1
		total_tier += int(f["tier"])
	var avg: float = 0.0
	if pool.size() > 0:
		avg = float(total_tier) / float(pool.size())
	return {"total": pool.size(), "blood": blood, "bone": bone, "void": voids, "avg_tier": avg}

func reset_doctrine_for_play() -> void:
	doctrine_used_this_play = false
	clear_exhausted()

func clear_exhausted() -> void:
	for i in range(current_hand.size()):
		current_hand[i]["exhausted"] = false

func get_week_target(week: int) -> int:
	match week:
		1:
			return 15
		2:
			return 32
		3:
			return 65
		4:
			return 120
		5:
			return 210
		_:
			return 999

func get_shop_cost(week: int) -> int:
	var base_cost: int = 3
	if week >= 4:
		base_cost = 5
	elif week >= 2:
		base_cost = 4
	var discount: int = 0
	if relic_inventory["Tithe Discount"] > 0:
		discount = 1
	return max(2, base_cost - discount)

func get_shop_rarity_slots(week_cleared: int) -> Array[String]:
	if week_cleared <= 2:
		return ["COMMON", "COMMON", "UNCOMMON"]
	return ["COMMON", "UNCOMMON", "RARE"]

func add_relic(name: String) -> void:
	if not relic_inventory.has(name):
		return
	if name == "Ritual Knife":
		relic_inventory[name] = 1
	elif name == "The Third Knife":
		relic_inventory[name] = 1
	elif name == "Tithe Discount":
		relic_inventory[name] = 1
	elif name == "Black Candle":
		relic_inventory[name] = 1
	else:
		relic_inventory[name] += 1

func score_selected(selected_indices: Array) -> Dictionary:
	return _score_selected_internal(selected_indices, true, true, true)

func preview_selected(selected_indices: Array) -> Dictionary:
	return _score_selected_internal(selected_indices, false, false, false)

func _score_selected_internal(selected_indices: Array, apply_currency: bool, write_breakdown: bool, write_log: bool) -> Dictionary:
	var indices: Array[int] = []
	var seen: Dictionary = {}
	for idx in selected_indices:
		if not seen.has(idx):
			seen[idx] = true
			indices.append(idx)
	indices.sort()

	var ritual_copies: int = relic_inventory["Ritual Knife"]
	var third_knife: int = relic_inventory["The Third Knife"]
	var bone_copies: int = relic_inventory["Bone Idol"]
	var crimson_copies: int = relic_inventory["Crimson Book"]
	var hollow_copies: int = relic_inventory["Hollow Chant"]
	var order_copies: int = relic_inventory["Sacrificial Order"]
	var quick_copies: int = relic_inventory["Quick Chant"]
	var thin_copies: int = relic_inventory["Thin Blade"]
	var ossuary_copies: int = relic_inventory["Ossuary Standard"]
	var polisher_copies: int = relic_inventory["Bone Polisher"]
	var symmetry_copies: int = relic_inventory["Ritual Symmetry"]
	var calcify_copies: int = relic_inventory["Calcify"]
	var prism_copies: int = relic_inventory["Void Prism"]
	var candle_copies: int = relic_inventory["Black Candle"]
	var balanced_copies: int = relic_inventory["Balanced Offering"]

	var sacrificed_info: Array[Dictionary] = []
	var additive_total: int = 0
	var blood_gain: int = 0
	var void_count: int = 0
	var bone_count: int = 0
	var blood_count: int = 0
	var has_blood: bool = false
	var has_bone: bool = false
	var has_void: bool = false
	var doctrine_lines: Array[String] = []
	var doctrine_additive: int = 0
	var doctrine_exponent_bonus: int = 0
	var relic_lines: Array[String] = []
	var blood_terms: Array[String] = []
	var bone_terms: Array[String] = []
	var polisher_total: int = 0
	var refined_void_count: int = 0

	var ritual_indices: Array[int] = []
	var ritual_count: int = 0
	if third_knife > 0:
		ritual_count = min(3, indices.size())
	elif ritual_copies > 0:
		ritual_count = min(1, indices.size())
	for i in range(ritual_count):
		ritual_indices.append(indices[i])

	for idx in indices:
		var follower: Dictionary = current_hand[idx]
		var tier: int = follower["tier"]
		var trait_name: String = follower["trait"]
		var effective_tier: int = tier
		var ritual_applied: bool = false
		if ritual_indices.has(idx):
			effective_tier = tier * 2
			ritual_applied = true

		if trait_name == "BLOOD":
			blood_count += 1
			has_blood = true
			var blood_term: int = effective_tier + crimson_copies
			additive_total += blood_term
			blood_terms.append(str(blood_term))
		elif trait_name == "BONE":
			bone_count += 1
			has_bone = true
			var bone_term: int = effective_tier * (2 + bone_copies)
			additive_total += bone_term
			bone_terms.append(str(bone_term))
			if calcify_copies > 0:
				additive_total += 2 * calcify_copies
		else:
			has_void = true
			void_count += 1
			if int(tier) > 0:
				refined_void_count += 1

		sacrificed_info.append({
			"index": idx,
			"trait": trait_name,
			"tier": tier,
			"effective_tier": effective_tier,
			"ritual_applied": ritual_applied,
		})

	if indices.size() == 1 and thin_copies > 0:
		additive_total += 8 * thin_copies
	if indices.size() > 0 and quick_copies > 0:
		additive_total += 3 * quick_copies
	if bone_count >= 2 and ossuary_copies > 0:
		additive_total += 10 * ossuary_copies
	if polisher_copies > 0 and bone_count > 0:
		var highest_bone: int = 0
		for info in sacrificed_info:
			if info["trait"] == "BONE":
				highest_bone = max(highest_bone, int(info["tier"]))
		additive_total += highest_bone * polisher_copies
	if indices.size() % 2 == 0 and indices.size() > 0 and symmetry_copies > 0:
		additive_total += 12 * symmetry_copies

	# Doctrine additive modifiers (after trait + additive relics, before multiplicative modifiers)
	if selected_doctrine == "FLESH":
		if blood_count >= 3:
			doctrine_additive += 6
			doctrine_lines.append("Doctrine (Flesh): +6 (3+ BLOOD sacrificed)")
		elif blood_count == 0:
			doctrine_additive -= 6
			doctrine_lines.append("Doctrine (Flesh): -6 (no BLOOD sacrificed)")
	elif selected_doctrine == "RUIN":
		if bone_count > 0:
			var highest_tier: int = 0
			var highest_trait: String = ""
			for info in sacrificed_info:
				var t: int = int(info["tier"])
				if t > highest_tier:
					highest_tier = t
					highest_trait = info["trait"]
			if highest_trait == "BONE":
				doctrine_additive += 8
				doctrine_lines.append("Doctrine (Ruin): +8 (highest-tier sacrifice was BONE)")

	additive_total += doctrine_additive
	if additive_total < 0:
		additive_total = 0

	if indices.size() == 3 and order_copies > 0:
		additive_total *= int(pow(2.0, float(order_copies)))
	if balanced_copies > 0 and has_blood and has_bone and has_void:
		additive_total *= int(pow(2.0, float(balanced_copies)))

	var effective_void: int = void_count + prism_copies
	var base: int = 1 + effective_void
	if candle_copies > 0:
		base = max(2, base)
	var exponent: int = 1 if hollow_copies == 0 else (hollow_copies + 1)
	if selected_doctrine == "SILENCE" and void_count == 1:
		exponent += 1
		doctrine_exponent_bonus = 1
		doctrine_lines.append("Doctrine (Silence): +1 multiplier exponent (exactly 1 VOID)")
	var multiplier: int = int(pow(float(base), float(exponent)))
	var multiplier_bonus_factor: float = 1.0
	if refined_void_count > 0:
		multiplier_bonus_factor = 1.0 + (0.5 * float(refined_void_count))
		doctrine_lines.append("Doctrine (Ruin): refined VOID adds +0.5 multiplier each")
	var final_devotion: int = int(float(additive_total * multiplier) * multiplier_bonus_factor)

	var per_blood: int = 1 + relic_inventory["Blood Abacus"]
	blood_gain = blood_count * per_blood
	if apply_currency:
		blood_currency += blood_gain

	var lines: Array[String] = []
	lines.append("Sacrificed followers:")
	for info in sacrificed_info:
		var line: String = "#%d %s(%d)" % [info["index"] + 1, info["trait"], info["tier"]]
		if info["ritual_applied"]:
			line += " -> ritual tier %d" % [info["effective_tier"]]
		lines.append(line)

	lines.append("")
	lines.append("Additive total: %d" % [additive_total])
	if crimson_copies > 0:
		lines.append("Crimson Book: BLOOD +%d each" % [crimson_copies])
		relic_lines.append("Crimson Book +%d/BLOOD" % [crimson_copies])
	if bone_copies > 0:
		lines.append("Bone Idol: BONE x%d" % [2 + bone_copies])
		relic_lines.append("Bone Idol x%d BONE" % [2 + bone_copies])
	if calcify_copies > 0 and bone_count > 0:
		lines.append("Calcify: +%d per BONE" % [2 * calcify_copies])
		relic_lines.append("Calcify +%d/BONE" % [2 * calcify_copies])
	if thin_copies > 0 and indices.size() == 1:
		lines.append("Thin Blade: +%d" % [8 * thin_copies])
		relic_lines.append("Thin Blade +%d" % [8 * thin_copies])
	if quick_copies > 0 and indices.size() > 0:
		lines.append("Quick Chant: +%d" % [3 * quick_copies])
		relic_lines.append("Quick Chant +%d" % [3 * quick_copies])
	if ossuary_copies > 0 and bone_count >= 2:
		lines.append("Ossuary Standard: +%d" % [10 * ossuary_copies])
		relic_lines.append("Ossuary +%d" % [10 * ossuary_copies])
	if polisher_copies > 0 and bone_count > 0:
		var highest_bone_line: int = 0
		for info in sacrificed_info:
			if info["trait"] == "BONE":
				highest_bone_line = max(highest_bone_line, int(info["tier"]))
		polisher_total = highest_bone_line * polisher_copies
		lines.append("Bone Polisher: +%d" % [highest_bone_line * polisher_copies])
		relic_lines.append("Bone Polisher +%d" % [highest_bone_line * polisher_copies])
	if symmetry_copies > 0 and indices.size() % 2 == 0 and indices.size() > 0:
		lines.append("Ritual Symmetry: +%d" % [12 * symmetry_copies])
		relic_lines.append("Ritual Symmetry +%d" % [12 * symmetry_copies])
	if order_copies > 0 and indices.size() == 3:
		lines.append("Sacrificial Order: x%d" % [int(pow(2.0, float(order_copies)))])
		relic_lines.append("Sacrificial Order x%d" % [int(pow(2.0, float(order_copies)))])
	if balanced_copies > 0 and has_blood and has_bone and has_void:
		lines.append("Balanced Offering: x%d" % [int(pow(2.0, float(balanced_copies)))])
		relic_lines.append("Balanced Offering x%d" % [int(pow(2.0, float(balanced_copies)))])
	if third_knife > 0 and ritual_indices.size() > 0:
		lines.append("The Third Knife applied to first three selected")
		relic_lines.append("Third Knife x2 first 3")
	elif ritual_copies > 0 and ritual_indices.size() > 0:
		lines.append("Ritual Knife applied to first selected")
		relic_lines.append("Ritual Knife x2 first 1")
	if doctrine_lines.size() > 0:
		lines.append("Doctrine modifiers:")
		for dl in doctrine_lines:
			lines.append(" * " + dl)

	lines.append("")
	var per_blood_display: int = 1 + relic_inventory["Blood Abacus"]
	lines.append("Blood gain: %d (count %d x per %d)" % [blood_gain, blood_count, per_blood_display])
	lines.append("Void count: %d" % [void_count])
	if prism_copies > 0:
		lines.append("Void Prism: void_count +%d = %d" % [prism_copies, effective_void])
		relic_lines.append("Void Prism +%d void" % [prism_copies])
	if candle_copies > 0:
		lines.append("Black Candle: base at least 2")
		relic_lines.append("Black Candle base>=2")
	if refined_void_count > 0:
		lines.append("Refined VOID: +0.5 multiplier each (%d total)" % [refined_void_count])
	lines.append("Multiplier: base %d ^ exp %d = %d" % [base, exponent, multiplier])
	lines.append("")
	lines.append("Final devotion: %d" % [final_devotion])

	var target: int = get_week_target(current_week)
	var pass_fail: String = "PASS" if final_devotion >= target else "FAIL"
	lines.append("Target: %d -> %s" % [target, pass_fail])

	var breakdown: String = "\n".join(lines)
	if write_breakdown:
		last_breakdown_text = breakdown
	if write_log:
		_write_debug_log(indices, sacrificed_info, additive_total, base, exponent, multiplier, final_devotion, blood_gain, target)

	return {
		"final_devotion": final_devotion,
		"breakdown": breakdown,
		"blood_gain": blood_gain,
		"void_count": void_count,
		"blood_count": blood_count,
		"bone_count": bone_count,
		"per_blood": per_blood,
		"base": base,
		"exponent": exponent,
		"multiplier": multiplier,
		"additive_total": additive_total,
		"relic_lines": relic_lines,
		"doctrine_lines": doctrine_lines,
		"blood_terms": blood_terms,
		"bone_terms": bone_terms,
		"refined_void_count": refined_void_count,
		"calcify_total": (bone_count * 2 * calcify_copies),
		"quick_total": (3 * quick_copies if indices.size() > 0 else 0),
		"thin_total": (8 * thin_copies if indices.size() == 1 else 0),
		"ossuary_total": (10 * ossuary_copies if bone_count >= 2 else 0),
		"polisher_total": polisher_total,
		"symmetry_total": (12 * symmetry_copies if indices.size() % 2 == 0 and indices.size() > 0 else 0),
		"order_mult": (int(pow(2.0, float(order_copies))) if indices.size() == 3 and order_copies > 0 else 1),
		"balanced_mult": (int(pow(2.0, float(balanced_copies))) if balanced_copies > 0 and has_blood and has_bone and has_void else 1),
		"doctrine_additive": doctrine_additive,
		"target": target,
		"pass": final_devotion >= target,
	}

func _write_debug_log(indices: Array[int], sacrificed_info: Array[Dictionary], additive_total: int, base: int, exponent: int, multiplier: int, final_devotion: int, blood_gain: int, target: int) -> void:
	var lines: Array[String] = []
	lines.append("=== Round Log ===")
	lines.append("Week: %d  Round: %d" % [current_week, week_round])
	lines.append("Target: %d" % target)
	lines.append("Doctrine: %s" % (selected_doctrine if selected_doctrine != "" else "none"))
	lines.append("Relics: %s" % _relic_summary())
	lines.append("Selected order (indices): %s" % [str(indices)])
	lines.append("Sacrificed details:")
	for info in sacrificed_info:
		var line: String = "#%d %s(%d) effective=%d ritual=%s" % [
			info["index"] + 1,
			info["trait"],
			info["tier"],
			info["effective_tier"],
			str(info["ritual_applied"]),
		]
		lines.append(line)
	lines.append("Additive total: %d" % additive_total)
	lines.append("Void base: %d  exponent: %d  multiplier: %d" % [base, exponent, multiplier])
	lines.append("Final devotion: %d" % final_devotion)
	var per_blood: int = 1 + relic_inventory["Blood Abacus"]
	lines.append("Blood gain: %d (per %d)  Blood total: %d" % [blood_gain, per_blood, blood_currency])
	lines.append("")
	_append_log(lines)

func _append_log(lines: Array[String]) -> void:
	var path: String = "user://debug_log.txt"
	var file: FileAccess = FileAccess.open(path, FileAccess.WRITE_READ)
	if file == null:
		return
	file.seek_end()
	for line in lines:
		file.store_line(line)
	file.flush()

func log_message(msg: String) -> void:
	print(msg)
	last_logs.append(msg)
	while last_logs.size() > 10:
		last_logs.pop_front()

func _relic_summary() -> String:
	var parts: Array[String] = []
	for name in RELICS:
		var count: int = relic_inventory.get(name, 0)
		if count > 0:
			parts.append("%s=%d" % [name, count])
	if parts.is_empty():
		return "none"
	return ", ".join(parts)
