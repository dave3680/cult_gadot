# Slice 3: Pool Agency (Cull / Favor)

## Objective
Give the player controlled agency over pool composition to support targeted builds.

## Systems Introduced Or Modified
- Add a `Cull` and `Favor` mechanic in the Shop phase.
- Modify pool management to allow limited removal or weighting.

## Why This Slice Is Sequenced Here
After adding traits and beliefs, players need tools to shape pool composition without raw scaling.

## Detailed System Description
- **Cull**: remove 1 follower from the pool per week (limited by cost or token).
- **Favor**: mark 1 follower or trait group to slightly increase its draw weight next week.
- Favor is temporary (1 week) to avoid runaway.
- Cull is limited (for example, 1 per week) and cannot reduce pool below 6.

## Required Data Model Changes
- Add `favor_tag` or `favor_id` on pool state with expiration.
- Add `cull_history` tracking for analytics and balance.

## UI Implications
- Shop adds a small Cull/Favor panel with minimal controls.
- Pool view supports selecting a follower to cull or favor.
- No layout redesign; add buttons in existing Shop side panel.

## Risk Analysis (Balance Dangers)
- Risk: too strong targeting reduces roguelike variance.
- Mitigation: strict weekly limit, temporary favor only, and cost scaling by week.

## Interaction With Existing Systems
- Pool draw logic respects favor weighting.
- Cull interacts with breeding by removing candidates.
- Recruit offers can be used to recover after aggressive culls.

## Done Criteria
- Player can Cull 1 follower per week in the Shop.
- Player can Favor 1 follower or trait group for next week.
- Favor expires automatically and cannot stack.
- Pool cannot be culled below 6.
