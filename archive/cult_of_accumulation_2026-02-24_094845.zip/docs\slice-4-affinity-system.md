# Slice 4: Affinity System (Hidden Combinatorial Axis)

## Objective
Add a hidden, emergent system that builds depth without UI overload or multiplier stacking.

## Systems Introduced Or Modified
- Introduce hidden `Affinity` values per follower.
- Affinity influences breeding and belief mutation probability subtly.

## Why This Slice Is Sequenced Here
After explicit traits and beliefs are in play, a hidden axis provides emergent combinations and replayability.

## Detailed System Description
- Each follower has a hidden affinity vector (for example, 2�3 axes such as `Devotion`, `Decay`, `Echo`).
- Affinities are not displayed, only hinted via behavior (for example, slightly higher mutation rates).
- When two followers share high affinity overlap, breeding chance or mutation chance slightly increases.
- Affinity is affected by sacrifice history or `origin_tag`, but is slow-moving.

## Required Data Model Changes
- Add `affinity` to follower data.
- Add pool-level affinity tuning constants.
- Add breeding formula adjustments that reference affinity.

## UI Implications
- No explicit UI elements.
- Optional minimal tooltip in advanced view later; for now, none.

## Risk Analysis (Balance Dangers)
- Risk: hidden system feels unfair if too strong.
- Mitigation: keep effects mild and consistent; provide subtle textual hints in event logs.

## Interaction With Existing Systems
- Breeding formula and belief mutation chances are slightly adjusted by affinity overlap.
- No direct scoring impact.

## Done Criteria
- Affinity values are generated for all followers.
- Breeding outcome probabilities are subtly influenced.
- Players can perceive effects via logs or outcomes, without explicit UI.
