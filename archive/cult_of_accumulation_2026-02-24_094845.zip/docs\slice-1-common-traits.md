# Slice 1: Common Traits (Lightweight)

## Objective
Introduce a lightweight, low-variance trait layer to increase combinatorial depth without increasing raw scaling.

## Systems Introduced Or Modified
- Follower definition gains a `common_trait` slot.
- Sacrifice resolution reads common traits for small, controlled effects.
- Breeding inherits or mutates common traits at low intensity.

## Why This Slice Is Sequenced Here
Establishes a safe, modular property system before adding rarer, higher-impact belief mutations.

## Detailed System Description
- Each follower has one common trait (for example: `Steady`, `Fickle`, `Feral`).
- Common traits provide small tactical or procedural effects, not raw additive spikes.
- Examples of effect shapes:
- Draw-phase micro-effects (for example: +1 reroll once per week if you sacrifice a `Steady` follower).
- Sacrifice-phase gating (for example: `Fickle`: if sacrificed with another same-trait follower, add +1 Blood).
- Effects are capped per play to avoid stacking runaway.

## Required Data Model Changes
- Add `common_trait` to follower data.
- Add `common_trait_source` (start/recruit/bred) if needed for debugging.
- Update save/persist logic to include the new field.

## UI Implications
- Pool view shows common trait icon and short label.
- Sacrifice view displays common trait under follower card.
- No layout refactor; reuse existing card slots and theme styles.

## Risk Analysis (Balance Dangers)
- Risk: traits stack additively without caps, causing early-week spikes.
- Mitigation: cap per week or per play triggers and keep effects minimal.

## Interaction With Existing Systems
- Scoring pipeline reads common traits but does not add new scoring layers.
- Breeding uses trait inheritance rules without changing pairing logic.

## Done Criteria
- Every follower has a `common_trait`.
- Traits are visible in pool and sacrifice screens.
- At least 6 common traits exist with capped, low-impact effects.
- Breeding can inherit or mutate traits without breaking cap or pool size rules.
