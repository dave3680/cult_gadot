extends Control

@onready var blood_label: Label = $RootVBox/TopBar/TopBarHBox/BloodLabel
@onready var skip_button: Button = $RootVBox/BottomArea/BottomHBox/SkipButton
@onready var shop_tab: Button = $RootVBox/TopBar/TopBarHBox/Tabs/ShopTab
@onready var pool_tab: Button = $RootVBox/TopBar/TopBarHBox/Tabs/PoolTab
@onready var offer_area: Control = $RootVBox/OfferArea
@onready var recruit_panel: Control = $RootVBox/RecruitPanel
@onready var recruit_msg: Label = $RootVBox/RecruitPanel/RecruitVBox/RecruitMsg
@onready var pool_area: Control = $RootVBox/PoolArea
@onready var pool_summary: Label = $RootVBox/PoolArea/PoolVBox/PoolSummary
@onready var pool_list: VBoxContainer = $RootVBox/PoolArea/PoolVBox/PoolScroll/PoolList
@onready var gs: Node = get_node("/root/GameState")

var offer_nodes: Array[Dictionary] = []
var offers: Array = []
var recruit_nodes: Array[Dictionary] = []
var _rng: RandomNumberGenerator = RandomNumberGenerator.new()

func _ready() -> void:
	_rng.randomize()
	offer_nodes = [
		{
			"name": $RootVBox/OfferArea/Offer1/Offer1VBox/Offer1Name,
			"rarity": $RootVBox/OfferArea/Offer1/Offer1VBox/Offer1Rarity,
			"desc": $RootVBox/OfferArea/Offer1/Offer1VBox/Offer1Desc,
			"cost": $RootVBox/OfferArea/Offer1/Offer1VBox/Offer1Cost,
			"buy": $RootVBox/OfferArea/Offer1/Offer1VBox/Offer1Buy,
		},
		{
			"name": $RootVBox/OfferArea/Offer2/Offer2VBox/Offer2Name,
			"rarity": $RootVBox/OfferArea/Offer2/Offer2VBox/Offer2Rarity,
			"desc": $RootVBox/OfferArea/Offer2/Offer2VBox/Offer2Desc,
			"cost": $RootVBox/OfferArea/Offer2/Offer2VBox/Offer2Cost,
			"buy": $RootVBox/OfferArea/Offer2/Offer2VBox/Offer2Buy,
		},
		{
			"name": $RootVBox/OfferArea/Offer3/Offer3VBox/Offer3Name,
			"rarity": $RootVBox/OfferArea/Offer3/Offer3VBox/Offer3Rarity,
			"desc": $RootVBox/OfferArea/Offer3/Offer3VBox/Offer3Desc,
			"cost": $RootVBox/OfferArea/Offer3/Offer3VBox/Offer3Cost,
			"buy": $RootVBox/OfferArea/Offer3/Offer3VBox/Offer3Buy,
		},
	]
	recruit_nodes = [
		{
			"trait": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit1/Recruit1VBox/Recruit1Trait,
			"stripe": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit1/Recruit1VBox/Recruit1Stripe,
			"tier": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit1/Recruit1VBox/Recruit1Tier,
			"origin": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit1/Recruit1VBox/Recruit1Origin,
			"buy": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit1/Recruit1VBox/Recruit1Buy,
		},
		{
			"trait": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit2/Recruit2VBox/Recruit2Trait,
			"stripe": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit2/Recruit2VBox/Recruit2Stripe,
			"tier": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit2/Recruit2VBox/Recruit2Tier,
			"origin": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit2/Recruit2VBox/Recruit2Origin,
			"buy": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit2/Recruit2VBox/Recruit2Buy,
		},
		{
			"trait": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit3/Recruit3VBox/Recruit3Trait,
			"stripe": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit3/Recruit3VBox/Recruit3Stripe,
			"tier": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit3/Recruit3VBox/Recruit3Tier,
			"origin": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit3/Recruit3VBox/Recruit3Origin,
			"buy": $RootVBox/RecruitPanel/RecruitVBox/RecruitRow/Recruit3/Recruit3VBox/Recruit3Buy,
		},
	]
	for i in range(recruit_nodes.size()):
		var buy_button: Button = recruit_nodes[i]["buy"]
		buy_button.pressed.connect(_on_buy_recruit.bind(i))

	skip_button.pressed.connect(_on_skip_pressed)
	shop_tab.pressed.connect(_on_shop_tab)
	pool_tab.pressed.connect(_on_pool_tab)
	_setup_offers()
	gs.generate_shop_recruits()
	_setup_recruits()
	_show_shop_view()

func _setup_offers() -> void:
	blood_label.text = "Blood: %d" % gs.blood_currency

	var week_cleared: int = gs.current_week
	var slots: Array[String] = gs.get_shop_rarity_slots(week_cleared)
	offers = _roll_offers(slots)
	var cost: int = gs.get_shop_cost(week_cleared)

	for i in range(offer_nodes.size()):
		var offer_name: String = offers[i]
		var node: Dictionary = offer_nodes[i]
		node["name"].text = offer_name
		node["rarity"].text = "Rarity: %s" % gs.RELIC_DEFS[offer_name]["rarity"]
		node["desc"].text = gs.RELIC_DEFS[offer_name]["desc"]
		node["cost"].text = "Cost: %d Blood" % cost
		var buy_button: Button = node["buy"]
		buy_button.disabled = gs.blood_currency < cost
		buy_button.pressed.connect(_on_buy_pressed.bind(i))

func _on_buy_pressed(index: int) -> void:
	var cost: int = gs.get_shop_cost(gs.current_week)
	if gs.blood_currency < cost:
		return
	gs.blood_currency -= cost
	gs.add_relic(offers[index])
	_finish_shop()

func _setup_recruits() -> void:
	recruit_msg.text = ""
	for i in range(recruit_nodes.size()):
		var node: Dictionary = recruit_nodes[i]
		var f: Dictionary = gs.shop_recruit_offers[i]
		node["trait"].text = "Trait: %s" % f["trait"]
		node["stripe"].color = _trait_color(f["trait"])
		node["tier"].text = "Tier: %d" % int(f["tier"])
		node["origin"].text = "Recruit"
		var buy_button: Button = node["buy"]
		buy_button.disabled = gs.blood_currency < 1 or gs.shop_recruit_purchased[i] or gs.pool.size() >= 40
		buy_button.text = "Hired" if gs.shop_recruit_purchased[i] else "Hire (1)"

func _on_buy_recruit(index: int) -> void:
	var result: Dictionary = gs.buy_shop_recruit(index)
	if not result["ok"]:
		if result["reason"] == "full":
			recruit_msg.text = "Pool is full."
		elif result["reason"] == "blood":
			recruit_msg.text = "Not enough Blood."
		return
	blood_label.text = "Blood: %d" % gs.blood_currency
	_setup_recruits()
	if pool_area.visible:
		_refresh_pool_list()

func _on_skip_pressed() -> void:
	_finish_shop()

func _finish_shop() -> void:
	var before: int = gs.blood_currency
	var interest_copies: int = gs.relic_inventory["Crimson Interest"]
	var interest_gain: int = 0
	if interest_copies > 0:
		interest_gain = int(floor(float(gs.blood_currency) / 5.0)) * interest_copies
		gs.blood_currency += interest_gain
	var after: int = gs.blood_currency
	gs.log_message("SHOP END | Week %d | Blood %d->%d (+%d interest) | Relics: %s | Offers: %s" % [
		gs.current_week,
		before,
		after,
		interest_gain,
		gs._relic_summary(),
		str(offers),
	])
	gs.perform_weekly_breeding(gs.current_week)
	gs.current_week += 1
	gs.start_week()
	get_tree().change_scene_to_file("res://scenes/RunGame.tscn")

func _roll_offers(slots: Array[String]) -> Array:
	var chosen: Array = []
	for rarity in slots:
		var pick: String = _pick_from_rarity(rarity, chosen)
		if pick == "":
			pick = _pick_from_rarity(_fallback_rarity(rarity), chosen)
		if pick != "":
			chosen.append(pick)
	return chosen

func _pick_from_rarity(rarity: String, exclude: Array) -> String:
	var pool: Array = []
	for name in gs.RELICS:
		if exclude.has(name):
			continue
		if gs.RELIC_DEFS[name]["rarity"] == rarity:
			pool.append(name)
	if pool.is_empty():
		return ""
	pool.shuffle()
	return pool[0]

func _fallback_rarity(rarity: String) -> String:
	if rarity == "RARE":
		return "UNCOMMON"
	if rarity == "UNCOMMON":
		return "COMMON"
	return "COMMON"

func _on_shop_tab() -> void:
	_show_shop_view()

func _on_pool_tab() -> void:
	_show_pool_view()

func _show_shop_view() -> void:
	shop_tab.button_pressed = true
	pool_tab.button_pressed = false
	offer_area.visible = true
	recruit_panel.visible = true
	pool_area.visible = false
	_setup_recruits()

func _show_pool_view() -> void:
	shop_tab.button_pressed = false
	pool_tab.button_pressed = true
	offer_area.visible = false
	recruit_panel.visible = false
	pool_area.visible = true
	_refresh_pool_list()

func _refresh_pool_list() -> void:
	for child in pool_list.get_children():
		child.queue_free()
	var summary: Dictionary = gs.pool_summary_counts()
	pool_summary.text = "Pool Size: %d | Blood: %d  Bone: %d  Void: %d | Avg Tier: %.1f" % [
		summary["total"],
		summary["blood"],
		summary["bone"],
		summary["void"],
		float(summary["avg_tier"]),
	]
	for f in gs.pool:
		var row: PanelContainer = PanelContainer.new()
		var hbox: HBoxContainer = HBoxContainer.new()
		row.add_child(hbox)
		var stripe: ColorRect = ColorRect.new()
		stripe.custom_minimum_size = Vector2(12, 0)
		stripe.color = _trait_color(f["trait"])
		hbox.add_child(stripe)
		var label: Label = Label.new()
		label.text = "%s  T%d  (%s #%d)" % [f["trait"], int(f["tier"]), f["origin_tag"], int(f["id"])]
		hbox.add_child(label)
		pool_list.add_child(row)

func _trait_color(trait_name: String) -> Color:
	match trait_name:
		"BLOOD":
			return Color(0.75, 0.2, 0.2)
		"BONE":
			return Color(0.85, 0.85, 0.85)
		"VOID":
			return Color(0.25, 0.2, 0.35)
		_:
			return Color(0.5, 0.5, 0.5)
