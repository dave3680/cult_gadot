# Slice 2: Rare Beliefs (Mutation Layer)

## Objective
Add a high-impact but rare belief mutation layer that shapes builds without directly increasing multipliers.

## Systems Introduced Or Modified
- New `belief` property for followers (rare).
- Mutation logic in breeding to create beliefs.
- Doctrine interactions with belief affinity.

## Why This Slice Is Sequenced Here
Builds on the common trait infrastructure with a rarer, more meaningful layer. Creates meaningful build direction before adding pool agency.

## Detailed System Description
- Beliefs are rare follower properties that trigger conditional effects.
- Example belief behaviors:
- `Ritualist`: If sacrificed as the highest tier, convert 1 Bone to Blood.
- `Echoed`: If sacrificed after a Void follower, copy 25% of Void multiplier bonus.
- Beliefs cannot stack multiplicatively; they are conditional conversions or cross-layer modifiers with fixed caps.
- Beliefs are mutually exclusive per follower (one belief max).

## Required Data Model Changes
- Add `belief_id` to follower data (nullable).
- Add `belief_rarity` and `belief_origin` for tracking.
- Add belief definition data (ids, rules, caps).

## UI Implications
- Add a belief badge and tooltip in pool and sacrifice views.
- Use existing tooltip or hover panels; no layout change.

## Risk Analysis (Balance Dangers)
- Risk: beliefs create hidden multiplier stacking or break early-week skill expression.
- Mitigation: beliefs modify conversions or gated bonuses only, with hard caps.

## Interaction With Existing Systems
- Beliefs integrate into the sacrifice resolution, likely between additive and multiplier or as a post-additive conversion step.
- Breeding mutation chance uses existing mutation framework.

## Done Criteria
- Beliefs are only generated through breeding mutation.
- Beliefs are visible and explained via UI tooltips.
- At least 8 beliefs exist with caps and no multiplicative stacking.
