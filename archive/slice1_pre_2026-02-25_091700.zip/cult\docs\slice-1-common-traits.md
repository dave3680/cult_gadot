# Slice 1: Core Power Curve & Target Alignment

## Objective
Establish a validated baseline power curve and target alignment for the run, so later balance slices are tuned against stable, measurable goals.

## Implementation Plan (Balance Focus)

### 1) Define balance targets
- Document explicit power bands per week:
  - Expected devotion range (per round and per week).
  - Acceptable win/loss rates by week.
  - Desired Blood gain per week (including overflow and early win bonuses).
- Specify target bands for “expert play” vs “average play.”

### 2) Introduce a Run Config object
- Create a config struct/data resource for all curve constants:
  - `MAX_WEEKS`, `TARGET_BASE`, `TARGET_GROWTH`.
  - Overflow conversion and weekly overflow cap.
  - Early win bonus.
- Ensure all references in `GameState.gd` read from this config.

### 3) Integrate config into GameState
- Refactor:
  - `get_week_target()`
  - `get_max_weeks()`
  - Overflow and early win logic
  - Week init logic
- Allow injecting config for simulation and tuning.

### 4) Expand simulation metrics
- Add per-week outputs:
  - Devotion achieved
  - Overflow gained
  - Blood earned/spent
  - Win/loss outcome
  - Pool size
- Produce per-week min/avg/max summaries.

### 5) Add validation checks
- Implement automated checks in `TestRunner.gd` against the balance targets.
- Fail the output if any week falls outside target bands.

### 6) Run tuning passes
- Iterate on `TARGET_BASE` / `TARGET_GROWTH` and bonus caps using the new metrics.
- Lock in constants once targets are met.

### 7) Document results
- Update `docs/Game_System_Documentation.md` with the final targets and config structure.
- Add a “Slice 1 Balance Spec” section with current numbers and rationale.

## Done Criteria
- Target curve hits defined win/loss rates in simulation for both expert and average profiles.
- Overflow and early win bonuses support progression without runaway economy.
- All week targets and caps are driven by the run config (no hard-coded constants in gameplay code).
