extends Node

const TEST_SEED := 7263491
const RUNS_PER_DOCTRINE := 2500
const RUN_BALANCE_SIM := true
const MAX_RELICS_PER_RUN := 10
const RUN_ONLY_SIM := true

var failures := []
var warnings := []
var report_lines := []
var test_count := 0
var pass_count := 0

func _ready() -> void:
	var started = Time.get_ticks_msec()
	run_all()
	var elapsed = Time.get_ticks_msec() - started
	_print_summary(elapsed)
	_write_report(elapsed)
	var exit_code := 0
	if failures.size() > 0:
		exit_code = 1
	get_tree().quit(exit_code)

func run_all() -> void:
	_print_header()
	if RUN_ONLY_SIM and RUN_BALANCE_SIM:
		run_balance_sim()
		return
	test_relic_scoring_exhaustive()
	test_relic_special_counts()
	test_relic_non_scoring_exhaustive()
	test_exactly_three_conditions()
	test_trait_effects()
	test_trait_multiplier_cap()
	test_breeding_rules()
	test_pool_cap_modifiers()
	test_intentional_failure()
	if RUN_BALANCE_SIM:
		run_balance_sim()

func _print_header() -> void:
	_log("")
	_log("=== Cult of Accumulation: Exhaustive Test Runner ===")
	_log("Seed: %d" % TEST_SEED)

func _print_summary(elapsed_ms: int) -> void:
	_log("")
	_log("=== Summary ===")
	_log("Tests: %d" % test_count)
	_log("Passing: %d" % pass_count)
	_log("Failures: %d" % failures.size())
	_log("Warnings: %d" % warnings.size())
	_log("Elapsed: %d ms" % elapsed_ms)
	if failures.size() > 0:
		for f in failures:
			_log("FAIL: " + f)
	if warnings.size() > 0:
		for w in warnings:
			_log("WARN: " + w)
	if failures.size() == 0:
		_log("PASS")

func _log(line: String) -> void:
	print(line)
	report_lines.append(line)

func _write_report(elapsed_ms: int) -> void:
	var date_str = Time.get_datetime_string_from_system()
	var dir_path = "res://docs/test_reports"
	var abs_dir = ProjectSettings.globalize_path(dir_path)
	DirAccess.make_dir_recursive_absolute(abs_dir)
	var file_path = dir_path + "/exhaustive_report_" + date_str.replace(":", "-") + ".txt"
	var f = FileAccess.open(file_path, FileAccess.WRITE)
	if f == null:
		print("WARN: Failed to write report to " + file_path)
		return
	for line in report_lines:
		f.store_line(line)
	f.store_line("")
	f.store_line("Report file: " + file_path)
	f.close()

func _fail(msg: String) -> void:
	failures.append(msg)

func _warn(msg: String) -> void:
	warnings.append(msg)

func _assert_true(cond: bool, msg: String) -> void:
	test_count += 1
	if not cond:
		_fail(msg)
	else:
		pass_count += 1

func _assert_eq(a, b, msg: String) -> void:
	test_count += 1
	if a != b:
		_fail("%s (got %s expected %s)" % [msg, str(a), str(b)])
	else:
		pass_count += 1

func _fresh_gs() -> Node:
	var GS = load("res://scripts/GameState.gd")
	var gs = GS.new()
	gs._ready()
	gs._rng.seed = TEST_SEED
	gs.reset_run()
	gs.suppress_logs = true
	gs.current_week = 1
	gs.week_round = 1
	gs.week_total_devotion = 0
	gs.selected_doctrine = ""
	gs.doctrine_used_this_play = false
	gs.ritual_card_active = ""
	gs.contract_allow_four = false
	gs.contract_used_week = -1
	return gs

func _make_exhaustive_hand(gs: Node) -> Array:
	var hand = []
	for tier in range(1, 7):
		hand.append(gs._make_specific_follower("BLOOD", tier, "test"))
	for tier in range(1, 7):
		hand.append(gs._make_specific_follower("BONE", tier, "test"))
	for i in range(6):
		hand.append(gs._make_specific_follower("VOID", 1, "test"))
	return hand

func _set_hand(gs: Node, hand: Array) -> void:
	gs.current_hand.clear()
	for f in hand:
		gs.current_hand.append(f)

func _score(gs: Node, indices: Array) -> Dictionary:
	return gs.preview_selected(indices)

func _has_line(text: String, needle: String) -> bool:
	var lines = text.split("\n")
	for l in lines:
		if l.find(needle) >= 0:
			return true
	return false

func run_balance_sim() -> void:
	_log("")
	_log("=== BalanceSim (Random Plays, With Relics) ===")
	var temp_gs = _fresh_gs()
	var max_weeks: int = int(temp_gs.get_max_weeks())
	temp_gs.free()
	var relic_run_counts: Dictionary = {}
	var relic_run_end_week_sum: Dictionary = {}
	var relic_run_avg_score_sum: Dictionary = {}
	var doctrine_summary: Dictionary = {}
	var doctrine_week_reached: Dictionary = {}
	var doctrine_blood_gained: Dictionary = {}
	var doctrine_blood_spent: Dictionary = {}
	var doctrines = ["FLESH", "RUIN", "SILENCE"]
	for doctrine in doctrines:
		doctrine_week_reached[doctrine] = {}
		doctrine_summary[doctrine] = {
			"runs": 0,
			"total_devotion": 0,
			"total_weeks_played": 0,
		}
		doctrine_blood_gained[doctrine] = 0
		doctrine_blood_spent[doctrine] = 0
		var week_passes: Array = []
		var week_loss_count: Array = []
		var week_loss_relics_sum: Array = []
		var week_round_sum: Array = []
		var week_round_count: Array = []
		var week_total_sum: Array = []
		for i in range(max_weeks):
			week_passes.append(0)
			week_loss_count.append(0)
			week_loss_relics_sum.append(0)
			week_round_sum.append(0)
			week_round_count.append(0)
			week_total_sum.append(0)
		for run_idx in range(RUNS_PER_DOCTRINE):
			var gs = _fresh_gs()
			gs.selected_doctrine = doctrine
			gs.init_starting_pool(doctrine)
			var run_relics: Dictionary = {}
			var run_total_devotion: int = 0
			var run_weeks_played: int = 0
			var run_end_week: int = 0
			var run_blood_gained: int = 0
			var run_blood_spent: int = 0
			for week in range(1, max_weeks + 1):
				gs.current_week = week
				gs.start_week()
				var target = gs.get_week_target(week)
				var week_cleared := false
				for round in range(2):
					gs.draw_hand_from_pool()
					var required = 3
					if gs.relic_inventory["Black Contract"] > 0 and gs.contract_used_week != week:
						if gs._rng.randf() < 0.5:
							gs.contract_allow_four = true
					if gs.contract_allow_four:
						required = 4
					var picks = _best_indices(gs, required)
					var blood_before: int = gs.blood_currency
					var result = gs.score_selected(picks)
					gs.week_total_devotion += int(result.get("final_devotion", 0))
					run_total_devotion += int(result.get("final_devotion", 0))
					var overflow_now: int = max(0, gs.week_total_devotion - target)
					var overflow_delta: int = overflow_now - gs.week_overflow_blood_granted
					if overflow_delta > 0:
						var remaining_overflow: int = max(0, 30 - gs.week_overflow_blood_granted)
						var grant: int = min(overflow_delta, remaining_overflow)
						if grant > 0:
							gs.week_overflow_blood_granted += grant
							gs.add_blood(grant)
					var blood_after: int = gs.blood_currency
					if blood_after > blood_before:
						run_blood_gained += (blood_after - blood_before)
					week_round_sum[week - 1] += int(result.get("final_devotion", 0))
					week_round_count[week - 1] += 1
					var typed_picks: Array[int] = []
					for p in picks:
						typed_picks.append(int(p))
					gs.resolve_play_and_update_pool(typed_picks)
					gs.week_round += 1
					gs.contract_allow_four = false
					if gs.week_total_devotion >= target:
						if round == 0:
							var blood_before_bonus: int = gs.blood_currency
							gs.add_blood(20)
							run_blood_gained += (gs.blood_currency - blood_before_bonus)
						week_cleared = true
						break
				run_weeks_played += 1
				run_end_week = week
				week_total_sum[week - 1] += gs.week_total_devotion
				if week_cleared or gs.week_total_devotion >= target:
					week_passes[week - 1] += 1
					run_blood_spent += _simulate_shop(gs, week, run_relics)
					gs.perform_weekly_breeding(week)
				else:
					# Failed week ends run early; still count remainder as fail
					week_loss_count[week - 1] += 1
					week_loss_relics_sum[week - 1] += _count_total_relics(gs)
					break
			var avg_score_run: float = 0.0
			if run_weeks_played > 0:
				avg_score_run = float(run_total_devotion) / float(run_weeks_played)
			doctrine_summary[doctrine]["runs"] = int(doctrine_summary[doctrine]["runs"]) + 1
			doctrine_summary[doctrine]["total_devotion"] = int(doctrine_summary[doctrine]["total_devotion"]) + run_total_devotion
			doctrine_summary[doctrine]["total_weeks_played"] = int(doctrine_summary[doctrine]["total_weeks_played"]) + run_weeks_played
			var reached = doctrine_week_reached[doctrine]
			reached[run_end_week] = int(reached.get(run_end_week, 0)) + 1
			doctrine_blood_gained[doctrine] = int(doctrine_blood_gained[doctrine]) + run_blood_gained
			doctrine_blood_spent[doctrine] = int(doctrine_blood_spent[doctrine]) + run_blood_spent
			for relic_name in run_relics.keys():
				relic_run_counts[relic_name] = int(relic_run_counts.get(relic_name, 0)) + 1
				relic_run_end_week_sum[relic_name] = int(relic_run_end_week_sum.get(relic_name, 0)) + run_end_week
				relic_run_avg_score_sum[relic_name] = float(relic_run_avg_score_sum.get(relic_name, 0.0)) + avg_score_run
			gs.free()

		_log("")
		_log("Doctrine: %s" % doctrine)
		for w in range(max_weeks):
			var pass_rate = float(week_passes[w]) / float(RUNS_PER_DOCTRINE)
			var avg_round = 0.0
			if week_round_count[w] > 0:
				avg_round = float(week_round_sum[w]) / float(week_round_count[w])
			var avg_week = float(week_total_sum[w]) / float(RUNS_PER_DOCTRINE)
			var avg_loss_relics = 0.0
			if week_loss_count[w] > 0:
				avg_loss_relics = float(week_loss_relics_sum[w]) / float(week_loss_count[w])
			_log("Week %d | PassRate: %.1f%% | AvgRound: %.2f | AvgWeek: %.2f" % [
				w + 1,
				pass_rate * 100.0,
				avg_round,
				avg_week
			])
			if week_loss_count[w] > 0:
				_log("Losses: %d | AvgRelicsOnLoss: %.2f" % [week_loss_count[w], avg_loss_relics])

	_log("")
	_log("=== Relic Impact (Avg Furthest Week, Avg Score) ===")
	var relic_rows: Array = []
	for relic_name in relic_run_counts.keys():
		var count: int = int(relic_run_counts[relic_name])
		if count <= 0:
			continue
		var avg_week: float = float(relic_run_end_week_sum[relic_name]) / float(count)
		var avg_score: float = float(relic_run_avg_score_sum[relic_name]) / float(count)
		relic_rows.append({"name": relic_name, "avg_week": avg_week, "avg_score": avg_score, "count": count})
	relic_rows.sort_custom(func(a, b):
		if a["avg_week"] == b["avg_week"]:
			return a["avg_score"] > b["avg_score"]
		return a["avg_week"] > b["avg_week"]
	)
	for i in range(relic_rows.size()):
		var r = relic_rows[i]
		_log("%d) %s | AvgWeek: %.2f | AvgScore: %.2f | RunsWithRelic: %d" % [
			i + 1,
			r["name"],
			float(r["avg_week"]),
			float(r["avg_score"]),
			int(r["count"]),
		])

	_write_sim_csv(max_weeks, relic_rows, doctrine_summary, doctrine_week_reached, doctrine_blood_gained, doctrine_blood_spent)

func _random_unique_indices(size: int, count: int, rng: RandomNumberGenerator) -> Array:
	var indices = []
	for i in range(size):
		indices.append(i)
	indices.shuffle()
	var picks = []
	for i in range(min(count, indices.size())):
		picks.append(indices[i])
	return picks

func _best_indices(gs: Node, required: int) -> Array:
	var size: int = gs.current_hand.size()
	if required <= 0 or size == 0:
		return []
	if required == 3:
		return _best_indices_3(gs, size)
	if required == 4:
		return _best_indices_4(gs, size)
	return _random_unique_indices(size, required, gs._rng)

func _best_indices_3(gs: Node, size: int) -> Array:
	var best: Array = []
	var best_score: int = -1
	var best_blood: int = -1
	for i in range(size - 2):
		for j in range(i + 1, size - 1):
			for k in range(j + 1, size):
				var combo = [i, j, k]
				var preview: Dictionary = gs.preview_selected(combo)
				var score: int = int(preview.get("final_devotion", 0))
				var blood: int = int(preview.get("blood_gain", 0))
				if score > best_score or (score == best_score and blood > best_blood):
					best_score = score
					best_blood = blood
					best = combo
	return best

func _best_indices_4(gs: Node, size: int) -> Array:
	var best: Array = []
	var best_score: int = -1
	var best_blood: int = -1
	for i in range(size - 3):
		for j in range(i + 1, size - 2):
			for k in range(j + 1, size - 1):
				for l in range(k + 1, size):
					var combo = [i, j, k, l]
					var preview: Dictionary = gs.preview_selected(combo)
					var score: int = int(preview.get("final_devotion", 0))
					var blood: int = int(preview.get("blood_gain", 0))
					if score > best_score or (score == best_score and blood > best_blood):
						best_score = score
						best_blood = blood
						best = combo
	return best

func _count_total_relics(gs: Node) -> int:
	var total := 0
	for k in gs.relic_inventory.keys():
		total += int(gs.relic_inventory[k])
	return total

func _simulated_relic_offers(gs: Node, week: int) -> Array:
	var offers = []
	for i in range(3):
		var rarity = gs.roll_shop_rarity(week, gs._rng)
		var pool = []
		for name in gs.RELICS:
			if not gs.RELIC_DEFS.has(name):
				continue
			var def = gs.RELIC_DEFS[name]
			if str(def.get("rarity", "")) != rarity:
				continue
			if not gs.can_offer_relic(name):
				continue
			pool.append(name)
		if pool.is_empty():
			continue
		pool.shuffle()
		offers.append(pool[0])
	return offers

func _simulate_shop(gs: Node, week: int, run_relics: Dictionary) -> int:
	var blood_spent: int = 0
	# Success bonuses before shop
	var bonus_cup = int(gs.relic_inventory.get("Ceremonial Cup", 0))
	var bonus_geo = int(gs.relic_inventory.get("Blasphemous Geometry", 0))
	var bonus_bowl = int(gs.relic_inventory.get("Brass Tithe Bowl", 0))
	if bonus_cup > 0:
		gs.add_blood(bonus_cup)
	if bonus_geo > 0:
		gs.add_blood(bonus_geo * 3)
	if bonus_bowl > 0:
		gs.add_blood(bonus_bowl)

	# Relic offers (random), allow multiple purchases
	var cost = gs.get_shop_cost(week)
	var offers = _simulated_relic_offers(gs, week)
	for i in range(offers.size()):
		if not gs.can_afford_relic(cost):
			break
		if _count_total_relics(gs) >= MAX_RELICS_PER_RUN:
			break
		var pick = _pick_rarest_relic(gs, offers)
		if pick == "":
			break
		blood_spent += cost
		gs.spend_blood_for_relic(cost)
		gs.add_relic(pick)
		run_relics[pick] = true
		# Remove purchased relic from this shop's offers (no auto-restock)
		offers.erase(pick)

	# One reroll per shop, cost 5 (free if chalk or free reroll available)
	if gs.shop_rerolls_used == 0:
		var reroll_cost: int = 5
		if gs.relic_inventory["Sharpened Chalk"] > 0 or gs.shop_free_reroll_available:
			reroll_cost = 0
		if gs.blood_currency >= reroll_cost:
			if reroll_cost > 0:
				blood_spent += reroll_cost
				gs.blood_currency -= reroll_cost
			gs.shop_rerolls_used += 1
			gs.shop_free_reroll_available = false
			offers = _simulated_relic_offers(gs, week)
			for i in range(offers.size()):
				if not gs.can_afford_relic(cost):
					break
				if _count_total_relics(gs) >= MAX_RELICS_PER_RUN:
					break
				var pick2 = _pick_rarest_relic(gs, offers)
				if pick2 == "":
					break
				blood_spent += cost
				gs.spend_blood_for_relic(cost)
				gs.add_relic(pick2)
				run_relics[pick2] = true
				offers.erase(pick2)

	# Recruits: generate and buy randomly while blood remains
	gs.generate_shop_recruits()
	for i in range(gs.shop_recruit_offers.size()):
		if gs.blood_currency <= 0:
			break
		if gs._rng.randf() < 0.5:
			var before_recruit: int = gs.blood_currency
			gs.buy_shop_recruit(i)
			var after_recruit: int = gs.blood_currency
			if after_recruit < before_recruit:
				blood_spent += (before_recruit - after_recruit)

	# Crimson Interest after shop
	var interest_copies = int(gs.relic_inventory.get("Crimson Interest", 0))
	if interest_copies > 0:
		var interest_gain = int(floor(float(gs.blood_currency) / 5.0)) * interest_copies
		if interest_gain > 0:
			gs.add_blood(interest_gain)

	gs.boost_pool_tiers_weekly()
	return blood_spent

func _write_sim_csv(max_weeks: int, relic_rows: Array, doctrine_summary: Dictionary, doctrine_week_reached: Dictionary, doctrine_blood_gained: Dictionary, doctrine_blood_spent: Dictionary) -> void:
	var date_str = Time.get_datetime_string_from_system().replace(":", "-")
	var dir_path = "res://docs/test_reports"
	var abs_dir = ProjectSettings.globalize_path(dir_path)
	DirAccess.make_dir_recursive_absolute(abs_dir)
	var file_path = dir_path + "/sim_metrics_" + date_str + ".csv"
	var f = FileAccess.open(file_path, FileAccess.WRITE)
	if f == null:
		_log("WARN: Failed to write CSV to " + file_path)
		return
	f.store_line("section,doctrine,week,relic,avg_week,avg_score,runs_with_relic,runs,total_devotion,total_weeks_played,avg_score_per_week,blood_gained,blood_spent,count")
	for doctrine in doctrine_summary.keys():
		var summary = doctrine_summary[doctrine]
		var runs: int = int(summary["runs"])
		var total_devotion: int = int(summary["total_devotion"])
		var total_weeks: int = int(summary["total_weeks_played"])
		var avg_score: float = 0.0
		if total_weeks > 0:
			avg_score = float(total_devotion) / float(total_weeks)
		var gained: int = int(doctrine_blood_gained[doctrine])
		var spent: int = int(doctrine_blood_spent[doctrine])
		f.store_line("doctrine_summary,%s,,,%0.2f,%0.2f,,%d,%d,%d,%0.2f,%d,%d," % [
			doctrine, 0.0, 0.0, runs, total_devotion, total_weeks, avg_score, gained, spent
		])
		var reached = doctrine_week_reached[doctrine]
		for w in range(1, max_weeks + 1):
			var count: int = int(reached.get(w, 0))
			f.store_line("week_reached,%s,%d,,,,,,,%d,,,,,%d" % [doctrine, w, 0, count])
	for r in relic_rows:
		f.store_line("relic_impact,,,%s,%0.2f,%0.2f,%d,,,,,,," % [
			r["name"],
			float(r["avg_week"]),
			float(r["avg_score"]),
			int(r["count"]),
		])
	f.close()

func _pick_rarest_relic(gs: Node, offers: Array) -> String:
	var best: String = ""
	var best_rank: int = -1
	for name in offers:
		if not gs.RELIC_DEFS.has(name):
			continue
		var rarity: String = str(gs.RELIC_DEFS[name].get("rarity", ""))
		var rank: int = _rarity_rank(rarity)
		if rank > best_rank:
			best_rank = rank
			best = name
	if best == "" and offers.size() > 0:
		return str(offers[0])
	return best

func _rarity_rank(rarity: String) -> int:
	match rarity:
		"LEGENDARY":
			return 4
		"RARE":
			return 3
		"UNCOMMON":
			return 2
		"COMMON":
			return 1
		_:
			return 0

func test_relic_scoring_exhaustive() -> void:
	var scoring = [
		"Ritual Knife",
		"Bone Idol",
		"Crimson Book",
		"Hollow Chant",
		"Sacrificial Order",
		"Quick Chant",
		"Ossuary Standard",
		"Bone Polisher",
		"Calcify",
		"Void Prism",
		"Black Candle",
		"The Third Knife",
		"Balanced Offering",
		"Prayer Beads",
		"Wax Seal",
		"Choir Robes",
		"Ossuary Standards",
		"Hollow Abacus",
		"Triune Reliquary",
		"Bloodright Almanac",
		"Cold Incense",
		"Ectoplasm Jar",
	]
	var gs = _fresh_gs()
	var hand = _make_exhaustive_hand(gs)
	_set_hand(gs, hand)

	var n = hand.size()
	for relic in scoring:
		for k in gs.relic_inventory.keys():
			gs.relic_inventory[k] = 0
		gs.relic_inventory[relic] = 1
		for i in range(n - 2):
			for j in range(i + 1, n - 1):
				for k in range(j + 1, n):
					var combo = [i, j, k]
					for rk in gs.relic_inventory.keys():
						gs.relic_inventory[rk] = 0
					var base = int(_score(gs, combo).get("final_devotion", 0))
					gs.relic_inventory[relic] = 1
					var with_relic = int(_score(gs, combo).get("final_devotion", 0))
					_assert_true(with_relic >= base, "Scoring relic reduced devotion: %s" % relic)
					# Stronger assertions for pure additive triggers
					if relic == "Prayer Beads":
						var t0 = str(hand[i]["trait"])
						var t1 = str(hand[j]["trait"])
						var t2 = str(hand[k]["trait"])
						if t0 == t1 and t1 == t2:
							_assert_true(with_relic > base, "Prayer Beads should add devotion when all traits match")
					elif relic == "Wax Seal":
						var tiers = {}
						var t_a = int(hand[i]["tier"])
						var t_b = int(hand[j]["tier"])
						var t_c = int(hand[k]["tier"])
						tiers[t_a] = int(tiers.get(t_a, 0)) + 1
						tiers[t_b] = int(tiers.get(t_b, 0)) + 1
						tiers[t_c] = int(tiers.get(t_c, 0)) + 1
						var has_pair := false
						for key in tiers.keys():
							if int(tiers[key]) >= 2:
								has_pair = true
								break
						if has_pair:
							_assert_true(with_relic > base, "Wax Seal should add devotion when any pair exists")
					elif relic == "Choir Robes":
						var t_a2 = int(hand[i]["tier"])
						var t_b2 = int(hand[j]["tier"])
						var t_c2 = int(hand[k]["tier"])
						if t_a2 != t_b2 and t_a2 != t_c2 and t_b2 != t_c2:
							_assert_true(with_relic > base, "Choir Robes should add devotion for all different tiers")
					elif relic == "Triune Reliquary":
						var has_blood := false
						var has_bone := false
						var has_void := false
						for idx in combo:
							var tr = str(hand[idx]["trait"])
							if tr == "BLOOD":
								has_blood = true
							elif tr == "BONE":
								has_bone = true
							else:
								has_void = true
						if has_blood and has_bone and has_void:
							_assert_true(with_relic > base, "Triune Reliquary should add devotion for BLOOD+BONE+VOID")
					elif relic == "Ossuary Standard":
						var bone_count := 0
						if str(hand[i]["trait"]) == "BONE":
							bone_count += 1
						if str(hand[j]["trait"]) == "BONE":
							bone_count += 1
						if str(hand[k]["trait"]) == "BONE":
							bone_count += 1
						if bone_count >= 2:
							_assert_true(with_relic > base, "Ossuary Standard should add devotion with 2+ BONE")
					elif relic == "Crimson Book":
						if str(hand[i]["trait"]) == "BLOOD" or str(hand[j]["trait"]) == "BLOOD" or str(hand[k]["trait"]) == "BLOOD":
							_assert_true(with_relic > base, "Crimson Book should add devotion with any BLOOD")
					elif relic == "Bone Idol" or relic == "Ossuary Standards" or relic == "Calcify" or relic == "Bone Polisher":
						if str(hand[i]["trait"]) == "BONE" or str(hand[j]["trait"]) == "BONE" or str(hand[k]["trait"]) == "BONE":
							_assert_true(with_relic > base, "%s should add devotion with any BONE" % relic)
					elif relic == "Quick Chant":
						_assert_true(with_relic >= base, "Quick Chant should never reduce devotion")
					elif relic == "Sacrificial Order":
						if base > 0:
							_assert_true(with_relic > base, "Sacrificial Order should add devotion on 3 sacrifices")

func test_relic_special_counts() -> void:
	var gs = _fresh_gs()
	var hand = _make_exhaustive_hand(gs)
	_set_hand(gs, hand)

	# Thin Blade: 1 sacrifice only
	for k in gs.relic_inventory.keys():
		gs.relic_inventory[k] = 0
	var base1 = int(_score(gs, [0]).get("final_devotion", 0))
	gs.relic_inventory["Thin Blade"] = 1
	var with1 = int(_score(gs, [0]).get("final_devotion", 0))
	_assert_true(with1 > base1, "Thin Blade should apply on 1 sacrifice")

	# Ritual Symmetry: even-numbered sacrifices (2 or 4)
	for k in gs.relic_inventory.keys():
		gs.relic_inventory[k] = 0
	var base2 = int(_score(gs, [0, 1]).get("final_devotion", 0))
	gs.relic_inventory["Ritual Symmetry"] = 1
	var with2 = int(_score(gs, [0, 1]).get("final_devotion", 0))
	_assert_true(with2 > base2, "Ritual Symmetry should apply on 2 sacrifices")

func test_relic_non_scoring_exhaustive() -> void:
	var non_scoring = [
		"Ceremonial Cup",
		"Blood Abacus",
		"Tithe Discount",
		"Crimson Interest",
		"Blasphemous Geometry",
		"Brass Tithe Bowl",
		"Sharpened Chalk",
		"Bone Saw",
		"Red Thread",
		"Grave Ledger",
		"Culling Knife",
		"Salt Circle",
		"Spare Chalice",
		"Blood Market Stall",
		"Debt Scripture",
		"Votive Mirror",
		"Fertility Idol",
		"Selective Breeding Scroll",
		"Clean Hands",
		"Black Contract",
		"Omen Deck",
		"Director's Cut",
		"Scarlet Planetarium",
		"Seal of Inheritance",
		"The Soul Lantern",
		"First Apostle",
	]
	var gs = _fresh_gs()
	var hand = _make_exhaustive_hand(gs)
	_set_hand(gs, hand)
	var n = hand.size()
	for relic in non_scoring:
		for k in gs.relic_inventory.keys():
			gs.relic_inventory[k] = 0
		gs.relic_inventory[relic] = 1
		for i in range(n - 2):
			for j in range(i + 1, n - 1):
				for k in range(j + 1, n):
					var combo = [i, j, k]
					for rk in gs.relic_inventory.keys():
						gs.relic_inventory[rk] = 0
					var base = int(_score(gs, combo).get("final_devotion", 0))
					gs.relic_inventory[relic] = 1
					var with_relic = int(_score(gs, combo).get("final_devotion", 0))
					_assert_eq(with_relic, base, "Non-scoring relic changed devotion unexpectedly: %s" % relic)

func test_exactly_three_conditions() -> void:
	var gs = _fresh_gs()
	# Sacrificial Order: any 3 sacrifices
	var hand = [
		gs._make_specific_follower("BLOOD", 1, "test"),
		gs._make_specific_follower("BONE", 1, "test"),
		gs._make_specific_follower("BLOOD", 2, "test"),
		gs._make_specific_follower("VOID", 1, "test"),
	]
	_set_hand(gs, hand)
	var combo3 = [0, 1, 2]
	var combo4 = [0, 1, 2, 3]
	for k in gs.relic_inventory.keys():
		gs.relic_inventory[k] = 0
	var base3 = int(_score(gs, combo3).get("final_devotion", 0))
	var base4 = int(_score(gs, combo4).get("final_devotion", 0))
	gs.relic_inventory["Sacrificial Order"] = 1
	var with3 = int(_score(gs, combo3).get("final_devotion", 0))
	var with4 = int(_score(gs, combo4).get("final_devotion", 0))
	_assert_true(with3 > base3, "Sacrificial Order should apply on 3 sacrifices")
	_assert_eq(with4, base4, "Sacrificial Order should not apply on 4 sacrifices")

	# Prayer Beads: all same trait
	gs = _fresh_gs()
	hand = [
		gs._make_specific_follower("BLOOD", 1, "test"),
		gs._make_specific_follower("BLOOD", 2, "test"),
		gs._make_specific_follower("BLOOD", 3, "test"),
		gs._make_specific_follower("BONE", 1, "test"),
	]
	_set_hand(gs, hand)
	combo3 = [0, 1, 2]
	combo4 = [0, 1, 2, 3]
	for k in gs.relic_inventory.keys():
		gs.relic_inventory[k] = 0
	base3 = int(_score(gs, combo3).get("final_devotion", 0))
	base4 = int(_score(gs, combo4).get("final_devotion", 0))
	gs.relic_inventory["Prayer Beads"] = 1
	with3 = int(_score(gs, combo3).get("final_devotion", 0))
	with4 = int(_score(gs, combo4).get("final_devotion", 0))
	_assert_true(with3 > base3, "Prayer Beads should apply on 3 sacrifices")
	_assert_eq(with4, base4, "Prayer Beads should not apply on 4 sacrifices")

	# Choir Robes: all different tiers
	gs = _fresh_gs()
	hand = [
		gs._make_specific_follower("BLOOD", 1, "test"),
		gs._make_specific_follower("BONE", 2, "test"),
		gs._make_specific_follower("BLOOD", 3, "test"),
		gs._make_specific_follower("BONE", 3, "test"),
	]
	_set_hand(gs, hand)
	combo3 = [0, 1, 2]
	combo4 = [0, 1, 2, 3]
	for k in gs.relic_inventory.keys():
		gs.relic_inventory[k] = 0
	base3 = int(_score(gs, combo3).get("final_devotion", 0))
	base4 = int(_score(gs, combo4).get("final_devotion", 0))
	gs.relic_inventory["Choir Robes"] = 1
	with3 = int(_score(gs, combo3).get("final_devotion", 0))
	with4 = int(_score(gs, combo4).get("final_devotion", 0))
	_assert_true(with3 > base3, "Choir Robes should apply on 3 sacrifices")
	_assert_eq(with4, base4, "Choir Robes should not apply on 4 sacrifices")

	# Triune Reliquary: BLOOD + BONE + VOID
	gs = _fresh_gs()
	hand = [
		gs._make_specific_follower("BLOOD", 1, "test"),
		gs._make_specific_follower("BONE", 1, "test"),
		gs._make_specific_follower("VOID", 1, "test"),
		gs._make_specific_follower("BLOOD", 2, "test"),
	]
	_set_hand(gs, hand)
	combo3 = [0, 1, 2]
	combo4 = [0, 1, 2, 3]
	for k in gs.relic_inventory.keys():
		gs.relic_inventory[k] = 0
	base3 = int(_score(gs, combo3).get("final_devotion", 0))
	base4 = int(_score(gs, combo4).get("final_devotion", 0))
	gs.relic_inventory["Triune Reliquary"] = 1
	with3 = int(_score(gs, combo3).get("final_devotion", 0))
	with4 = int(_score(gs, combo4).get("final_devotion", 0))
	_assert_true(with3 > base3, "Triune Reliquary should apply on 3 sacrifices")
	_assert_eq(with4, base4, "Triune Reliquary should not apply on 4 sacrifices")

	# Bloodright Almanac: Blood Straight
	gs = _fresh_gs()
	hand = [
		gs._make_specific_follower("BLOOD", 1, "test"),
		gs._make_specific_follower("BLOOD", 2, "test"),
		gs._make_specific_follower("BLOOD", 3, "test"),
		gs._make_specific_follower("BONE", 1, "test"),
	]
	_set_hand(gs, hand)
	combo3 = [0, 1, 2]
	combo4 = [0, 1, 2, 3]
	for k in gs.relic_inventory.keys():
		gs.relic_inventory[k] = 0
	base3 = int(_score(gs, combo3).get("final_devotion", 0))
	base4 = int(_score(gs, combo4).get("final_devotion", 0))
	gs.relic_inventory["Bloodright Almanac"] = 1
	with3 = int(_score(gs, combo3).get("final_devotion", 0))
	with4 = int(_score(gs, combo4).get("final_devotion", 0))
	_assert_true(with3 > base3, "Bloodright Almanac should apply on 3 sacrifices")
	_assert_eq(with4, base4, "Bloodright Almanac should not apply on 4 sacrifices")

func test_trait_effects() -> void:
	var gs = _fresh_gs()
	var hand: Array = [
		gs._make_specific_follower("BLOOD", 2, "test"),
		gs._make_specific_follower("BONE", 2, "test"),
		gs._make_specific_follower("BLOOD", 1, "test"),
	]
	_set_hand(gs, hand)
	var base = int(_score(gs, [0, 1, 2]).get("final_devotion", 0))
	hand[0]["trait_id"] = "devout"
	var with_devout = int(_score(gs, [0, 1, 2]).get("final_devotion", 0))
	_assert_eq(with_devout - base, 1, "Devout should add +1 additive")

	hand[1]["trait_id"] = "stalwart"
	var with_stalwart = int(_score(gs, [0, 1, 2]).get("final_devotion", 0))
	_assert_true(with_stalwart - with_devout >= 2, "Stalwart should add +2 additive when BONE")

	# Fervent: +1 Blood if exactly 3
	hand[0]["trait_id"] = ""
	hand[1]["trait_id"] = ""
	hand[2]["trait_id"] = ""
	var base_blood = int(_score(gs, [0, 1, 2]).get("blood_gain", 0))
	hand[0]["trait_id"] = "fervent"
	var result = _score(gs, [0, 1, 2])
	_assert_eq(int(result.get("blood_gain", 0)), base_blood + 1, "Fervent should grant +1 Blood on exactly 3")

	# Twinborn: +3 additive if another shares tier
	hand[0]["trait_id"] = ""
	hand[1]["trait_id"] = ""
	hand[2]["trait_id"] = ""
	hand[0]["tier"] = 2
	hand[1]["tier"] = 2
	hand[2]["tier"] = 4
	var base2 = int(_score(gs, [0, 1, 2]).get("final_devotion", 0))
	hand[0]["trait_id"] = "twinborn"
	var with2 = int(_score(gs, [0, 1, 2]).get("final_devotion", 0))
	_assert_eq(with2 - base2, 3, "Twinborn should add +3 additive when tiers match")

	# Ossuary King: +12 additive if 2+ BONE
	hand = [
		gs._make_specific_follower("BONE", 1, "test", "ossuary_king"),
		gs._make_specific_follower("BONE", 1, "test"),
		gs._make_specific_follower("BLOOD", 1, "test"),
	]
	_set_hand(gs, hand)
	var r1 = _score(gs, [0, 1, 2])
	_assert_true(int(r1.get("final_devotion", 0)) >= 12, "Ossuary King should add +12 additive")

	# Martyr's Ledger: +2 Blood
	var base_blood2 = int(_score(gs, [0, 1, 2]).get("blood_gain", 0))
	hand[0]["trait_id"] = "martyrs_ledger"
	var r2 = _score(gs, [0, 1, 2])
	_assert_eq(int(r2.get("blood_gain", 0)), base_blood2 + 2, "Martyr's Ledger should grant +2 Blood")

	# Blood Prophet and Straight Rite: check multiplier lines
	hand = [
		gs._make_specific_follower("BLOOD", 1, "test", "blood_prophet"),
		gs._make_specific_follower("BLOOD", 2, "test"),
		gs._make_specific_follower("BLOOD", 3, "test"),
	]
	_set_hand(gs, hand)
	var r3 = _score(gs, [0, 1, 2])
	_assert_true(_has_line(str(r3.get("breakdown", "")), "multiplier exponent +1"), "Blood Prophet should report exponent bonus")

	hand[0]["trait_id"] = "straight_rite"
	var r4 = _score(gs, [0, 1, 2])
	_assert_true(_has_line(str(r4.get("breakdown", "")), "multiplier exponent +1"), "Straight Rite should report exponent bonus")

	# Void Herald: multiplier base +1 if exactly 1 VOID
	hand = [
		gs._make_specific_follower("VOID", 1, "test", "void_herald"),
		gs._make_specific_follower("BLOOD", 1, "test"),
		gs._make_specific_follower("BONE", 1, "test"),
	]
	_set_hand(gs, hand)
	var r5 = _score(gs, [0, 1, 2])
	_assert_true(_has_line(str(r5.get("breakdown", "")), "multiplier base +1"), "Void Herald should report base bonus")

	# Black Candlebearer: base min 2 if 0 VOID
	hand = [
		gs._make_specific_follower("BLOOD", 1, "test", "black_candlebearer"),
		gs._make_specific_follower("BLOOD", 1, "test"),
		gs._make_specific_follower("BONE", 1, "test"),
	]
	_set_hand(gs, hand)
	var r6 = _score(gs, [0, 1, 2])
	_assert_true(_has_line(str(r6.get("breakdown", "")), "multiplier base"), "Black Candlebearer should report base bonus")

func test_trait_multiplier_cap() -> void:
	var gs = _fresh_gs()
	var hand = [
		gs._make_specific_follower("VOID", 1, "test", "void_herald"),
		gs._make_specific_follower("BLOOD", 1, "test", "whispered"),
		gs._make_specific_follower("BONE", 1, "test"),
	]
	_set_hand(gs, hand)
	var r = _score(gs, [0, 1, 2])
	var breakdown = str(r.get("breakdown", ""))
	_assert_true(_has_line(breakdown, "multiplier base +1"), "One multiplier trait should apply")
	_assert_true(_has_line(breakdown, "multiplier trait cap"), "Extra multiplier trait should be capped")

func test_breeding_rules() -> void:
	# Fertility Idol increases chance for non-VOID couples
	var gs = _fresh_gs()
	gs.relic_inventory["Fertility Idol"] = 2
	var chance = gs._breeding_chance("BLOOD", "BONE")
	_assert_true(chance >= 0.55, "Fertility Idol should increase breeding chance (expected >= 0.55)")

	# Seal of Inheritance: if parent has a trait, newborn should inherit
	gs = _fresh_gs()
	var parent_a = gs._make_specific_follower("BLOOD", 2, "test", "devout")
	var parent_b = gs._make_specific_follower("BONE", 2, "test")
	gs.relic_inventory["Seal of Inheritance"] = 1
	var trait_id = gs._roll_breeding_trait(parent_a, parent_b)
	_assert_eq(trait_id, "devout", "Seal of Inheritance should force parent trait when present")

	# Chosen of the Veil: newborn should always have a trait if parent has chosen_veil
	gs = _fresh_gs()
	parent_a = gs._make_specific_follower("BLOOD", 2, "test", "chosen_veil")
	parent_b = gs._make_specific_follower("BONE", 2, "test")
	var trait_id2 = gs._roll_breeding_trait(parent_a, parent_b)
	_assert_true(trait_id2 != "", "Chosen of the Veil should guarantee a trait")

func test_pool_cap_modifiers() -> void:
	var gs = _fresh_gs()
	gs.relic_inventory["Salt Circle"] = 3
	var cap = gs.get_pool_cap()
	_assert_eq(cap, 1000 + 12, "Salt Circle should increase pool cap by +4 per copy")
	gs.relic_inventory["Ectoplasm Jar"] = 2
	var cap2 = gs.get_pool_cap()
	_assert_eq(cap2, 1000 + 12 - 12, "Ectoplasm Jar should reduce pool cap by -6 per copy")

func test_intentional_failure() -> void:
	_assert_true(false, "Intentional failing test to verify runner reports failures")
