extends Control

@onready var summary_label: Label = $Center/Panel/VBox/Summary
@onready var continue_button: Button = $Center/Panel/VBox/ContinueButton
@onready var gs: Node = get_node("/root/GameState")

func _ready() -> void:
	summary_label.text = gs.last_breeding_summary if gs.last_breeding_summary != "" else "No breeding results."
	continue_button.pressed.connect(_on_continue_pressed)

func _on_continue_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/RunGame.tscn")
