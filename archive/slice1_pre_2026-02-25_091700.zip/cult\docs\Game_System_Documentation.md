# Game System Documentation (Current Repository)

Last updated: 2026-02-24

This document replaces the previous version and reflects the current repository state. It covers every file, all implemented gameplay systems, and the interactions between them. Partial or missing systems are explicitly marked.

---

**Repository Overview**
- Engine: Godot 4.4 (Forward+)
- Entry Scene: `res://scenes/MainMenu.tscn`
- Global State: `GameState` autoload (`res://scripts/GameState.gd`)
- Core Loop: Doctrine selection ? Run (week, up to 2 rounds) ? Shop ? Breeding ? Run ? � ? Victory/Game Over
- Run Length: 10 weeks (`MAX_WEEKS`)

---

**File Inventory (All Files in Repository)**

**Project/Engine**
- `project.godot`: Godot project config. Defines main scene and autoloads.
- `icon.svg`, `icon.svg.import`: Game icon and Godot import metadata.
- `.editorconfig`, `.gitattributes`, `.gitignore`: Repo tooling config.
- `.godot/`: Godot editor cache and metadata.

**Scenes (UI & Flow)**
- `scenes/MainMenu.tscn`: Main menu UI; start button.
- `scenes/DoctrineSelect.tscn`: Doctrine selection UI (Flesh/Ruin/Silence).
- `scenes/RunGame.tscn`: Main gameplay (hand, breakdown, doctrine, rituals, pool overlay).
- `scenes/Shop.tscn`: Shop UI (relics, recruits, ritual, pool management, pack, next round).
- `scenes/Breeding.tscn`: Post-shop breeding summary and continue.
- `scenes/Victory.tscn`: Victory screen.
- `scenes/GameOver.tscn`: Game over screen.
- `scenes/TestRunner.tscn`: Headless test/sim entry point.

**Scripts**
- `scripts/GameState.gd`: Core gameplay state and rule logic (traits, relics, scoring, pool, breeding, shop rules, economy, targets, logging, RNG).
- `scripts/MainMenu.gd`: Main menu logic (transition to Doctrine selection).
- `scripts/DoctrineSelect.gd`: Doctrine choice and run initialization.
- `scripts/RunGame.gd`: Run loop UI and per-round handling (selection, scoring, continue, overflow, victory/shop transitions).
- `scripts/Shop.gd`: Shop UI logic (relic offers, recruits, rerolls, ritual cards, pool actions, relic pack, shop exit).
- `scripts/Breeding.gd`: Breeding results scene logic and return to Run.
- `scripts/Victory.gd`: Victory UI logic (back to menu).
- `scripts/GameOver.gd`: Game over UI logic (back to menu).
- `scripts/TestRunner.gd`: Automated tests and balance simulation.

**Godot UID Files**
- `scripts/*.uid`: Godot metadata for script resources.

**Docs**
- `docs/Game_System_Documentation.md`: This document.
- `docs/slice-1-common-traits.md` � `docs/slice-5-pre-boss-balancing.md`: Design slices and goals.
- `docs/test_reports/*`: Test/sim outputs (exhaustive reports, sim CSVs, Godot translation artifacts).

**Archive**
- `archive/*.zip`, `archive/*.tar.gz`: Snapshot archives of the project.
- `archive/_extract/*`: Extracted archive used for restoration and comparisons.

---

# System Dependency Graph (Text)
- All scenes depend on `GameState` for state and rule execution.
- `RunGame.gd` depends on `GameState` for hand draw, scoring, doctrine, ritual consumption, overflow and rewards.
- `Shop.gd` depends on `GameState` for relic definitions, rarity rolls, recruit generation, pool actions, ritual offers, and shop exit flow.
- `Breeding.gd` depends on `GameState.last_breeding_summary`.
- `TestRunner.gd` instantiates `GameState` directly and reuses scoring, pool, relic, and breeding logic.
- No NavMesh, physics, combat navigation, or pathfinding systems exist in this repo.

---

# Gameplay Loop Breakdown
1. **Main Menu** ? Start
2. **Doctrine Select** ? Initialize run + starting pool
3. **Run (Week)**
   - Up to 2 rounds per week
   - Select 3 (or 4 with Black Contract) followers to sacrifice
   - Score devotion; apply overflow and blood gains
   - If week target met: win and go to Shop
   - If week target not met after round 2: Game Over
4. **Shop**
   - Buy relics (no auto-restock; can reroll once)
   - Buy recruits; pool actions (cull, favor, ascend, apostle)
   - Ritual card purchase (if Scarlet Planetarium owned)
   - Optional relic pack by sacrificing 10 followers
5. **Breeding Scene**
   - Shows breeding summary
   - Continue returns to Run for next week
6. Repeat until **Week 10** ? Victory

---

# Technical Loop Breakdown
- `MainMenu.gd` ? `DoctrineSelect.gd`
- `DoctrineSelect.gd` ? `GameState.reset_run()`, `init_starting_pool()`, `start_week()` ? `RunGame.tscn`
- `RunGame.gd` uses `GameState.score_selected()` and `resolve_play_and_update_pool()` for each round
- `Shop.gd` rolls offers via `GameState.roll_shop_rarity()` and relic definitions
- Shop exit applies `GameState.boost_pool_tiers_weekly()` and `perform_weekly_breeding()` then enters `Breeding.tscn`
- `Breeding.gd` reads `GameState.last_breeding_summary` and returns to `RunGame.tscn`

---

# Systems (Implemented)

## 1. Run Lifecycle & Global State
**Purpose**: Single source of truth for all run data.

**Core Mechanics**
- Initializes and resets runs.
- Stores week progression, blood, pool, relic inventory, traits, and logs.

**Technical Architecture**
- Script: `scripts/GameState.gd`
- Autoload: `GameState` (via `project.godot`)

**Dependencies**
- Depended on by all scenes and the test runner.

**Data Flow**
- `reset_run()` ? `init_starting_pool()` ? `start_week()`
- All gameplay systems mutate `GameState`.

**Limitations**
- Monolithic script (logic + data + UI strings).

**Expansion Hooks**
- Split subsystems (scoring, economy, shop, breeding) into modules.

---

## 2. Doctrine System
**Purpose**: Run-defining path with a once-per-play action.

**Core Mechanics**
- Flesh: convert 1 follower to BLOOD.
- Ruin: +1 tier then exhaust that card this play.
- Silence: banish and replace a follower.

**Technical Architecture**
- `scripts/DoctrineSelect.gd` (selection), `scripts/RunGame.gd` (use), `scripts/GameState.gd` (state).

**Limitations**
- Actions are hard-coded; no upgrade tiers.

---

## 3. Follower Traits (BLOOD/BONE/VOID/SOUL)
**Purpose**: Core trait axis for devotion calculation.

**Core Mechanics**
- BLOOD: additive contribution = tier.
- BONE: additive contribution = tier * 2 (plus relic modifiers).
- VOID: multiplier base scaling.
- SOUL: exhausted filler (no devotion, no bonuses).

**Technical Architecture**
- Trait constants in `GameState.gd`.
- `ensure_pool_minimum_for_draw()` fills with SOUL.

**Limitations**
- SOUL is a hard fallback, not a designed archetype.

---

## 4. Trait/Belief System (Per-Follower Modifiers)
**Purpose**: Adds variance and micro-power to followers.

**Core Mechanics**
- Trait registry with common/rare traits.
- Applies additive, multiplier, and blood effects in scoring.
- One multiplier-trait cap per play.

**Technical Architecture**
- Data: `TRAIT_REGISTRY`, `COMMON_TRAIT_IDS`, `RARE_TRAIT_IDS` in `GameState.gd`.
- Displayed in `RunGame.gd` and `Shop.gd`.

**Limitations**
- Trait rules are hard-coded inside scoring logic.

---

## 5. Relic System
**Purpose**: Run-wide modifiers and shop rewards.

**Core Mechanics**
- 50 relics defined (rarity, stack rules, category, description).
- Effects span scoring, economy, pool actions, breeding, rituals.
- Rarity re-assigned based on sim ranking.

**Technical Architecture**
- `RELICS` and `RELIC_DEFS` in `GameState.gd`.
- `Shop.gd` for offers; `RunGame.gd` for effects.

**Limitations**
- No data-driven effect system (logic embedded in code).

---

## 6. Scoring & Devotion
**Purpose**: Resolve sacrifices into devotion and blood.

**Core Mechanics**
- Additive + multiplier model.
- Relics, traits, doctrines, rituals all modify values.
- Multipliers: base and exponent system.

**Technical Architecture**
- `_score_selected_internal()` in `GameState.gd`.
- Breakdown strings built in scoring logic.

**Limitations**
- Tight coupling between logic and UI strings.

---

## 7. Hand & Sacrifice Resolution
**Purpose**: Select 3�4 followers per round to score.

**Core Mechanics**
- Hand drawn from pool (6 followers).
- Sacrificed followers removed, survivors return to pool.
- Ritual rebirth and resilient traits can override removal.

**Technical Architecture**
- `RunGame.gd` (UI selection), `GameState.gd` (`resolve_play_and_update_pool`).

---

## 8. Overflow & Early Win Bonuses
**Purpose**: Reward over-performance and fast clears.

**Core Mechanics**
- Overflow devotion ? Blood, capped at 30 per week.
- Early win (round 1) grants +20 Blood once per week.

**Technical Architecture**
- Implemented in `RunGame.gd` using `GameState.week_overflow_blood_granted`.

---

## 9. Economy (Blood)
**Purpose**: Currency for relics, recruits, rerolls, and rituals.

**Core Mechanics**
- Earned from devotion, bonuses, and relic effects.
- Spent on relics (fixed cost), recruits, rerolls, rituals.

**Technical Architecture**
- `blood_currency` and `add_blood/spend_blood_for_relic` in `GameState.gd`.

---

## 10. Week Targeting & Difficulty
**Purpose**: Defines week targets and run length.

**Core Mechanics**
- Target formula: `TARGET_BASE * TARGET_GROWTH^(week-1)`.
- Week cap: `MAX_WEEKS = 10`.
- Director�s Cut can override next week target.

**Technical Architecture**
- `get_week_target()` and `get_max_weeks()` in `GameState.gd`.
- UI uses these in `RunGame.gd`.

---

## 11. Shop System
**Purpose**: Post-week progression and choice density.

**Core Mechanics**
- 3 relic offers, rarity rolled by week:
  - Rare: 15% +2%/week (max 30%)
  - Legendary: 2% +1%/week (max 8%)
- **No auto-restock** when buying relics.
- Reroll: **one per shop**, cost 5 (free with Sharpened Chalk or Clean Hands).
- Recruit purchases cost 1 Blood.
- Ritual card purchase cost 2 Blood.

**Technical Architecture**
- `Shop.gd` (UI and logic), `GameState.gd` (rules and RNG).

---

## 12. Relic Pack (Pool Sacrifice ? Relic Choice)
**Purpose**: Trade 10 followers for a 2-choice relic pack.

**Core Mechanics**
- Select 10 followers in pool view.
- Offers 2 relics, guarantees at least one rare.
- Legendary chance scales slightly with average tier.
- Higher tiers improve rarity chances.

**Technical Architecture**
- `Shop.gd` builds and handles pack UI.
- Uses `GameState.roll_shop_rarity()` for pack rarity.

---

## 13. Recruits & Pool Agency
**Purpose**: Manipulate the follower pool in shop.

**Core Mechanics**
- Recruits: generated each shop; can be bought and sometimes copied.
- Pool actions (relic-gated):
  - Cull (Culling Knife)
  - Favored breeders (Selective Breeding Scroll)
  - Ascend (The Soul Lantern)
  - Apostle (First Apostle)

**Technical Architecture**
- `Shop.gd` handles UI and selection.
- `GameState.gd` applies actions.

---

## 14. Breeding System
**Purpose**: Weekly pool growth and inheritance.

**Core Mechanics**
- Pairs in pool; breeding chance based on traits and relics.
- Inheritance logic with relic overrides (Seal of Inheritance).
- Apostle parent boosts outcomes.
- Pool cap trims newborns if over cap.

**Technical Architecture**
- `GameState.perform_weekly_breeding()`.
- `Breeding.tscn` shows summary.

---

## 15. Ritual Cards (Partial)
**Purpose**: Single-use play modifiers.

**Core Mechanics**
- Shop offers ritual if Scarlet Planetarium owned.
- Three ritual cards: Anoint, Silence, Rebirth.
- Stored in slot, then activated during Run.

**Technical Architecture**
- `GameState` stores ritual state.
- `Shop.gd` offers and buys.
- `RunGame.gd` activates.

---

## 16. Test & Balance Simulation
**Purpose**: Automated validation + simulation metrics.

**Core Mechanics**
- Exhaustive relic/trait tests.
- Balance sim (expert play, best hand selection).
- Outputs CSV + report files in `docs/test_reports/`.

**Technical Architecture**
- `scripts/TestRunner.gd`.
- `scenes/TestRunner.tscn`.

**Limitations**
- RUN_ONLY_SIM=true skips tests entirely.

---

# Interactions (System-to-System)

- **Doctrine ? Scoring**: doctrine effects modify additive or multiplier rules.
- **Relics ? Scoring**: most relics modify additive, multiplier, or blood gain.
- **Relics ? Shop**: reroll discounts, recruit boosts, special actions.
- **Relics ? Breeding**: fertility, inheritance, apostle effects.
- **Traits ? Scoring**: traits add additive, multiplier base/exponent, or blood.
- **Pool ? Hand**: hand is a draw from pool; pool gets SOUL filler if empty.
- **Shop ? Pool**: recruits, cull, ascend, apostle, favored breeders.
- **Shop ? Breeding**: breeding resolves after shop.

---

# Scene Flow Map
- `MainMenu.tscn` ? `DoctrineSelect.tscn`
- `DoctrineSelect.tscn` ? `RunGame.tscn`
- `RunGame.tscn` ? `Shop.tscn` (week cleared)
- `Shop.tscn` ? `Breeding.tscn`
- `Breeding.tscn` ? `RunGame.tscn`
- `RunGame.tscn` ? `Victory.tscn` (week 10 cleared)
- `RunGame.tscn` ? `GameOver.tscn` (fail week after round 2)

---

# Slice Implementation Status

**Slice 1: Core Power Curve & Target Alignment**
- Implemented: week cap = 10; target curve formula; overflow cap; early win bonus; tier weighting.
- Missing: formal power band targets and sim validation targets; dedicated run config object.
- Status: **Partial**.

**Slice 2: Trait & Relic Power Pass**
- Implemented: trait system, multiplier trait cap, relic effects, rarity reassignment, pack UI for clearer choices.
- Missing: structured tuning pass and balancing across all relics/traits.
- Status: **Partial**.

**Slice 3: Economy & Shop Gamification**
- Implemented: reroll cost 5, one per shop; no auto-restock; ritual shop UI; relic pack.
- Missing: week-scaled relic costs; recruit pricing curve; economic targeting metrics.
- Status: **Partial**.

**Slice 4: Pool Growth, Breeding, and Synergy**
- Implemented: breeding rules, favored breeders, apostle, ascension, breeding summary scene; SOUL filler.
- Missing: deeper breeding strategy hooks, explicit telemetry for breeding outcome balance.
- Status: **Partial**.

**Slice 5: Late-Game Scaling & Run Completion**
- Implemented: 10-week cap integrated across UI and logic; victory condition uses max weeks.
- Missing: late-game tuning and soft caps for runaway scaling.
- Status: **Partial**.

---

# Architecture Summary
- Pattern: Autoloaded state singleton + scene controllers.
- State management: mutable global state, no event bus.
- Procedural generation: RNG inside `GameState` for followers, recruits, offers, breeding.
- Scoring integration: all relic/trait/doctrine effects converge in `_score_selected_internal`.
- Performance risk: exhaustive tests and large pool sizes; breakdown string assembly in scoring.
- Coupling risk: UI depends directly on `GameState` internals.

---

# Known Limitations & Risks
- Scene transitions currently rely on deferred scene changes to avoid tree-busy errors.
- UI layouts are brittle (Shop layout reverted to pre-scroll version; ritual panel may not fit smaller viewports).
- Balance data is hard-coded in `GameState.gd`.
- No persistence or meta-progression system exists.

---

# Recommended Next Steps (Design + Tech)
1. **Stabilize run config** (week cap, target curve, economy constants) into a data object.
2. **Data-drive relic and trait effects** to improve tuning and testing.
3. **Re-introduce safe shop layout fixes** (scrolling or responsive layout) without breaking scene loads.
4. **Add telemetry** for breeding, relic picks, and devotion per week for balance iteration.

---

# Appendix: Current Outputs
- Simulation and test outputs are written to `docs/test_reports/` with time-stamped files.
- Archive snapshots in `archive/` are used for rollback and diff comparisons.
